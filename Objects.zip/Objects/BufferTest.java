
public class BufferTest implements SingleBuffer {

	private Object test;


	
	public Object get( ) {
		try {
			if(test != null) {
				Object x=test;
				test = null;
				return x;
			}
			else {
				throw new Exception ("Buffer is empty"); 
			}
		}
		catch (Exception error) {
			return null;
		}
	}
	
	public void put (Object thing) {
		try {
			if(test == null) {
			test = thing;
			}
			else {
				throw new Exception ("Buffer is full");
			}


		}
		catch(Exception error) {
		}
	}


}
