
public class objArrayCopy {
	public static  <AnyType> void copyArr( AnyType [ ] a, AnyType [ ] b) {
		for(int i=0; i<a.length; i++) {
			a[i] = b[i];
		}

	}
	//Write a generic copy routine that moves elements from one array to
	//another identically sized and compatible array.
	
///////////////////////////////////////////////////////////////////////////////	
	
	
	public static Comparable getMin (Comparable [] arr) {
		int min =0;
		for(int i=0; i< arr.length; i++) {
			if( arr[i].compareTo( arr[min]) < 0 ) {
				min = i;
				//Write generic method min, which accepts an array and returns the
				//smallest item. Then use the method on the String type.
			}
		}
		return arr[min];
	}
	
	public static Comparable getMax(Comparable [] arr) {
		int max=0;
		for(int i=0; i<arr.length; i++) {
			if( arr[i].compareTo( arr[max] )> 0) {
				max=i;
			}
		}
		return arr[max];
		
	}
	
	public static void main( String [ ] args ) {
		
		String [] strArr= {"dog", "hello", "things", "Mr. Rogers"};
		
		System.out.println(getMin(strArr));
		
	
		//Write generic methods min and max, each of which accepts two parameters
		//and returns the smaller and larger, respectively. Then use those
		//me thods on the String type.
	}

}
