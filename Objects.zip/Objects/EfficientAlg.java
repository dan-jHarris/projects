
public class EfficientAlg {

	public static void findNumber(int [ ] a) {
		
		for(int i =0; i<a.length; i++) {
			if(a[i] == i) {
				System.out.println("The number is in the array");
				return;

			}
		}
		System.out.println("Not in array");
		
	}
}
/*Give an efficient algorithm to determine whether an integer i exists
such that A = i in an array of increasing integers. What is the running
time of your algorithm?*/