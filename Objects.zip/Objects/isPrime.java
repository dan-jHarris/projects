
public class isPrime {
	public static void prime(int n) {
		if(n%2 !=0) {
			for (int i=3; i<Math.sqrt(n); i++) {
				if(n%i == 0) {
					System.out.println("Is not prime");
					return;
				}
			}
			System.out.println("Is Prime");
			return;
		}
		System.out.println("Is not Prime");

	}
	public static void main (String [] args) {
		prime(19);
	}
//O(sqrt(N)) is the O notation
}
/*A prime number has no factors besides 1 and itself. Do the following:
a. Write a program to determine if a positive integer N is prime. In
terms of N, what is the worst-case running time of your program?*/