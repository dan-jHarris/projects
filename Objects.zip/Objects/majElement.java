import java.util.ArrayList;

public class majElement {
	public static void element (int [ ] arr) {
		int num=0;
		for(int i=0; i<(arr.length/2)+1; i++) {
			int counter=1;
			for(int j=i+1; j<arr.length; j++) {
				if(arr[i] == arr[j]) {
					counter++;
				}
			}
			if(counter > arr.length/2) {
				System.out.println(arr[i]);	
				return;
			}

		}
		System.out.println("There is no majority element");
	}

	public static void main (String [ ] args) {
		int [ ] a = { 4,5,8,40,6,10,4,4,5,6,7,8,9 };
		ArrayList arr = new ArrayList();
		for(int i=0; i<200000; i++) {
			arr.add(i);
			arr.trimToSize();
		}
		element(a);
	}
	
	
	
}
// O(N^2) is the proper O notation;

/*The ArrayList class contains a trim method that resizes the internal
array to exactly the capacity. The trim method is intended to be used
after all the items have been added the ArrayList, in order to avoid
wasting space. Suppose, however, the novice programmer invokes
trim after each add. In that case, what is the running time of building
an N-item ArrayList? Write a program that performs 100,000 adds to
an ArrayList and illustrates the novice�s error.*/