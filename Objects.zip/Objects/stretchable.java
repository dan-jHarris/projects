import java.util.ArrayList;

public interface stretchable {
	
	public static void stretchAll(ArrayList <? extends stretchable> arr, double factor) {
		for(stretchable s: arr)
			s.stretchShape(factor);
	
	}
	void stretchShape(double factor);

//Revise the stretchAll method to accept a ArrayList instead of an
//	array. Use wildcards to ensure that both ArrayList<Stretchable> and
//	ArrayList<Rectangle> are acceptable parameters
}

