public class Person implements Comparable <Person>
{
	public Person( String n, int ag, String ad, String p )
	{ name = n; age = ag; address = ad; phone = p; }

	public String toString( )
	{ return getName( ) + " " + getAge( ) + " "
			+ getPhoneNumber( ); }

	public String getName( )
	{ return name; }

	public int getAge( )
	{ return age; }

	public String getAddress( ){
		return address; }

	public String getPhoneNumber( )
	{ return phone; }

	public void setAddress( String newAddress )
	{ address = newAddress; }
	public void setPhoneNumber( String newPhone )
	{ phone = newPhone; }

	private String name;
	private int age;
	private String address;
	private String phone;
	
	public static void main (String [ ] args) {
		Person [ ] People = { new Person ("Dan", 22, "100W", "435-thing"), new Person ("Seth", 20, "Cedar", "123") };
		System.out.println(objArrayCopy.getMax(People)) ;
	}
	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
//Modify the Person class so that it can use findMax to obtain the alphabetically
//last person.