import java.util.ArrayList;

public class Library {
	private ArrayList <LibraryBook> shelf;
	public Library () {
		shelf = new ArrayList<LibraryBook>();
	}


	public void addABook (LibraryBook HP) {
		shelf.add(HP);
	}
	public void checkOut (int ISBN, String holder, String dueDate) {
		for(LibraryBook b: shelf) {
			if(b.getISBN()==ISBN) {
				b.setDueDate(dueDate);
				b.setHolder(holder);
				break;
			}
		}
	}
	public String findHolder (int ISBN) {
		for(LibraryBook b: shelf) {
			if(b.getISBN()==ISBN) {
				return b.getHolder();
			}
		}
		return ("Book does not exist");
	}
}

/*A book consists of an author, title, and ISBN number (all of which
can never change once the book is created).
A library book is a book that also contains a due date and the current
holder of the book, which is either a String representing a person who
has checked the book out or null if the book is currently not checked
out. Both the due date and holder of the book can change over time.
A library contains library books and supports the following
operations:
1. Add a library book to the library.
2. Check out a library book by specifying its ISBN number and
new holder and the due date.
3. Determine the current holder of a library book given its ISBN
number.
a. Write two interfaces: Book and LibraryBook that abstract the functionality
described above.
b. Write a library class that includes the three methods specified. In
implementing the Library class, you should maintain the library
books in an ArrayList. You may assume that there are never any
requests to add duplicate books.*/