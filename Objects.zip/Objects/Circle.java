
public class Circle extends Shape {

	public Circle( double rad ) {
		if (rad < 0) {
			throw new IllegalArgumentException ("Must be greater than 0");
		}
		radius =rad;

	}
	public double area ( ) {
		return Math.PI * radius *radius;
	}
	public double perimeter ( ) {
		return 2*Math.PI*radius;
		
	}
	private double radius;
	
}
//Modify the Circle class to implement Comparable<Circle>.