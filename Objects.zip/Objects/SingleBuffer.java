
public interface  SingleBuffer <AnyType> {
	public AnyType get ( );
	public void put (AnyType thing);
}
//4.37 - create SingleBuffer.  When the text says "Define an exception to signal errors" it really means throw an exception when code tries to read an empty buffer, or write to a full buffer


/*A SingleBuffer supports get and put: The SingleBuffer stores a single
item and an indication whether the SingleBuffer is logically empty. A
put may be applied only to an empty buffer, and it inserts an item into
the buffer. A get may be applied only to a nonempty buffer, and it
deletes and returns the contents of the buffer. Write a generic class to
implement SingleBuffer. Define an exception to signal errors.*/