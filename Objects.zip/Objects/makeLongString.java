
public class makeLongString {
	public static String makeLongString1(int N) {
		String result = "";
		for (int i = 0; i< N; i++) {
			result +="X";
		}
		return result;
	}
	public static String makeLongString2(int N) {
		StringBuilder result = new StringBuilder("");
		for (int i =0; i <N; i++) {
			result.append("x");
		}
		return new String(result);
	}
	public static void main(String args [ ]) {
		makeLongString1(55555);
		makeLongString1(99999);
		System.out.println("the makeLongString1 test lasted 4 seconds, runtime lasted N^2");
		
		
		makeLongString2(55555);
		makeLongString2(9999);
		System.out.println("the makeLongString2 test lasted less than 1 second, runtime lasted N");


		
		/*The equation has exactly one integral
solution that satisfies . Write a program
to find the solution. Hint: First, precompute all values of
and store them in an array. Then, for each tuple , you
only need to verify that some F exists in the array. (There are several
ways to check for F, one of which is to use a binary search to check
for F. Other methods might prove to be more efficient.)*/
		
		
	}

}
