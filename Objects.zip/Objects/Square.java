
public class Square extends Rectangle {

	public Square ( double side ) {
		// because square extends rectangle, the argument exception should apply here as well. 
		super( side, side ); 
		
	
	}

}
//Add a Square class into the Shape hierarchy, and have it implement
//Comparable<Square>.