
public class Shape {
		double area = 0;
		double distance =0;
		private double xPos=Math.random()*10;
		private double yPos=Math.random()*10;
	public static double totalArea( Shape [ ] arr) {
		double total = 0;
		
		for( Shape s: arr)
			if( s !=null )
				total += s.area;
		
		return total;
	
	}
	
	public static double distance (Shape a, Shape b) {
		double dis= Math.sqrt((Math.pow((a.xPos- b.xPos),2) + Math.pow((a.yPos - b.yPos),2)));
		
		return dis;
	}
	
	
	public static void printAll( Shape [] arr) {
		for( Shape s: arr)
			System.out.println( s );
	}
	public static void main( String [ ] args ) {
		Shape [ ] a = { new Circle(2.0), new Rectangle ( 1.0, 3.0 ), null };
		
		System.out.println( "Total area =" +totalArea (a ) );
		printAll( a );
		
		System.out.println( distance(a[0], a[1] ));
		
		//Add the concept of a position to the Shape hierarchy by including
		//coordinates as data members. Then add a distance method.
	}
}
//For the Shape example, modify the constructors in the hierarchy to
//Throw an InvalidArgumentException when the parameters are negative/