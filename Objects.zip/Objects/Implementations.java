
public class Implementations {
	private Object storedValue;
	public class MemoryCell implements Comparable < MemoryCell > {
		public Object rad( ) {
			return storedValue;
		}
		public void write (Object x ) {
			storedValue = x;
		}
		@Override
		public int compareTo(MemoryCell o) {
			if(equals(o)) {
				return 0;
			}
			return -1;
		}
	}
}
//Modify the MemoryCell to implement Comparable<MemoryCell>.

