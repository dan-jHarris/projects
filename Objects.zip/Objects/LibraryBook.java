
public class LibraryBook extends Book {
	private String dueDate;
	private String holder;

	public LibraryBook(String author, int ISBN, String title, String dueDate, String holder) {
	super(title, ISBN, author);
	this.dueDate=dueDate;
	this.holder = holder;
	
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getHolder() {
		return holder;
	}

	public void setHolder(String holder) {
		this.holder = holder;
	}
}
