
public class intSolution {

	
	public static void main (String [ ] args) {
		long [ ] arr  = new long [76];
		for(int i=1; i<76; i++ ){
			arr[i] = (long)(Math.pow(i,5));
		}
		
		
		for(int a=1; a <76; a++) {
			for( int b=a; b<76; b++) {
				for( int c=b; c<76; c++) {
					for( int d=c; d<76; d++) {
						for( int e=d; e<76; e++) {
							for( int f=e; f<76; f++) {
								if(arr[a]+arr[b]+arr[c]+arr[d]+arr[e]==arr[f]) {
									System.out.println( a + " "+ b + " "+c+ " "+d+ " "+e+"equals " +f );
								}
							}
						}
					}
				}
			}
		}
	}
}
/* As mentioned in Exercise 5.38, repeated String concatenation can be
expensive. Consequently, Java provides a StringBuilder class. A
StringBuilder is somewhat like an ArrayList that stores unlimited
characters. The StringBuilder allows one to easily add to the end,
automatically expanding an internal character array (by doubling its
capacity) as needed. In so doing, the cost of appending can be
assumed to be proportional to the number of characters added to the
StringBuilder (rather than the number of characters in the result). At
any point, the StringBuilder can be used to construct a String. Figure
5.16 contains two methods that return Strings containing N xs. What
is the running time of each method? Run the methods on various values
of N to verify your answer. */