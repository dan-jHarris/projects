
public class Book {
	private final String title;
	private final int ISBN;
	private final String author;

	
	public Book (String title, int ISBN, String author) {
			this.title = title;
			this.ISBN=ISBN;
			this.author=author;
	}


	public String getTitle() {
		return title;
	}


	public int getISBN() {
		return ISBN;
	}


	public String getAuthor() {
		return author;
	}
}
	/* new Scanner reader = new Scanner(new File("file.txt"))
int a =reader.nextInt(); 
if its a string, simply .next()
suround with try catch (Exception e) {}


*/