import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class TowerDefenseObject {
	private int posistionX;
	private int posistionY;
	private BufferedImage picture;
	private int width;
	private int height;

	public TowerDefenseObject() {
		posistionX=125;
		posistionY=125;
		width=10;
		height=10;
		picture=null;

	}
	public TowerDefenseObject(int x, int y, int width, int height, BufferedImage pic) {
		posistionX=x;
		posistionY=y;
		this.width=width;
		this.height=height;
		picture=pic;
	}
	
	public void drawTheImage(Graphics g) {
		g.drawImage(picture,posistionX,posistionY,width,height,null);


	}
	public int getPosistionX() {
		return posistionX;
	}
	public void setPosistionX(int posistionX) {
		this.posistionX = posistionX;
	}
	public int getPosistionY() {
		return posistionY;
	}
	public void setPosistionY(int posistionY) {
		this.posistionY = posistionY;
	}
	public BufferedImage getPicture() {
		return picture;
	}
	public void setPicture(BufferedImage picture) {
		this.picture = picture;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}

}