import javax.swing.JOptionPane;

/**
 * 
 * @author
 *
 */
public class GuiDesign{

	@SuppressWarnings("unused")
	public static void dialogBoxes(){
		String s = JOptionPane.showInputDialog("Please enter a number");
		//int x = ??;
		//JOptionPane.showMessageDialog(null, "The number you entered is " + ??);
		
	}
	
	public GuiDesign(){
		
		//JLabel
		//JTextField of size 10, with text already inside - uneditable
		//JPassword Field
		//JButton with the text Click Me
		//JCheckBox
	}

	
	public static void main(String[] args) {
		
		dialogBoxes();

		//GuiDesign g = new GuiDesign();
		
	}

}
