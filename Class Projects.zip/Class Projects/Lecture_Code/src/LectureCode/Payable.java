
public interface Payable {
	double getPaymentAmount(); //Why do we not need to use the terms public and abstract?
}
