

public class AccountTest {

	public static void main(String[] args) {
		Account a = new Account();
		String s = a.getName();
		System.out.println("The name is "+s);
a.setName("Dans Account");
	}

}
