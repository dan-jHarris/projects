/**
 * 
 * @author Dr. B.
 *
 */
public class PlayingCardTester {

	public static void main(String[] args) {
		//NOTE: You may have named the methods something other than I did.
		//Feel free to change this code.

		/* //Remove this one at a time.
		PlayingCard p1 = new PlayingCard(2,3,false); //Your code gets all information
		PlayingCard p2 = new PlayingCard(3,12); //Your code needs to make up a spacial orientation
		PlayingCard p3 = new PlayingCard(); //Your code needs to make up everything
		
		/*
		if (p1.getCardSuit() != 2){
			System.err.println("For some reason p1 does not have a suit of 2");
		}
		if (p2.getCardSuit() != 3){
			System.err.println("For some reason p2 does not have a suit of 3");
		}
		
		/*
		if (p1.getCardValue() != 3){
			System.err.println("For some reason p1 does not have a value of 3");
		}
		if (p2.getCardValue() != 12){
			System.err.println("For some reason p2 does not have a value of 12");
		}
		
		/*
		if(p1.getIsFaceUp() != false){
			System.err.println("For some reason p1 is not face down");
		}

		/*
		p3.setCardSuit(3);
		if (p3.getCardSuit() != 3){
			System.err.println("For some reason p3 does not have a suit of 3 after setting it");
		}

		/*
		p3.setCardValue(3);
		if (p3.getCardValue() != 3){
			System.err.println("For some reason p3 does not have a value of 3 after setting it");
		}
		
		/*
		p3.setIsFaceUp(true);
		if(p3.getIsFaceUp() != true){
			System.err.println("For some reason p3 is not face up after setting it");
		}

		/*

		 */

	}

}
