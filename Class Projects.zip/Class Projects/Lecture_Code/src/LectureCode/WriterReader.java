import java.util.Random;

/**
 * 
 * @author
 *
 */
public class WriterReader {

	public static void main(String[] args) {
		String filename = "tmp.txt";
		writeRandomNumbersToFile(filename);
		sumIntsInFile(filename);
	}
	
	@SuppressWarnings("unused")
	public static void writeRandomNumbersToFile(String filename){
		Random rand = new Random();
		//Use a Formatter
		
		for (int i = 0; i < 10; i++){
			int r = rand.nextInt(10);
			//Write r to the file
		}
	}
	
	public static void sumIntsInFile(String filename){
		int sum = 0;
		//Create a scanner
		
		//while( in.hasNext()){
		
	    //}
		System.out.println("The Sum Is: " + sum);
	}

}
