import java.util.Scanner;

/**
 * 
 * @author
 *
 */
public class ExceptionExamples {

	public static int divide(int a, int b) throws Exception{ 
		if(b != 0) {
			int x = a / b;
			return x;
		}
		else {
			throw new Exception();
		}
	}

	public static void main(String[] args) {
		boolean keepGoing = true;
		while (keepGoing) {
			try {
				Scanner in = new Scanner(System.in);
				System.out.println("Please enter a number for division: ");
				int userNumber = in.nextInt();
				int i=0;


				int i = divide(5,userNumber);


				System.out.println("divide returned " + i);
				in.close();
				keepGoing = false;
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("He, give me an integer. Please. Prett Please!");
			}
			catch (ArithmeticException e) {
				e.printStackTrace();
				System.out.println("Hey, don't divide by 0, my computer doesn't like it");
				
			}

		}
	}
}
