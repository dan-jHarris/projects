import java.awt.Color;

/**
 * 
 * @author Dr. B.
 *
 */
public class Car {

	private Color c;
	
	public Car(Color c){
		this.c = c;
	}
	
	public Color getColor(){
		return c;
	}
	
}
