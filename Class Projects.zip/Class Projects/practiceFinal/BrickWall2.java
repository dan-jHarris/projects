import java.awt.Color;

public class BrickWall {
	private int mBricks;
	private int sDonation;
	private Person p;
	private int cBricks;
	private Brick [] bricks;
	private Person hDonator;
	private int hDonation;
    private static int tDonation = 0; 
	private int sDonations;
	
	/**
	 * This is the 3 argument constructor
	 * A BrickWall created with this constructor should have 
	 * @param maxNumOfBricks This is how many bricks will be needed to build the wall
	 * @param startingDonation The amount of money donated by Person P
	 * @param p The Person who initially funded the building of the wall
	 * 
	 * Not shown is that you need to know
	 *   which Person donated the most
	 *   there are 0 bricks in the wall currently
	 *   A way to store all the Bricks
	 *   How much money was made for every brick wall, ever
	 *   Any other information you might need
	 * 
	 * GOTCHAS:
	 * There must always be at least 1 brick in the wall
	 * The starting donation must always be at least 10
	 * If p is invalid, create a new Person with the first name "Unknown" and last name "Donation"
	 * 
	 * 
	 */
	public BrickWall(int maxNumOfBricks, int startingDonation, Person p){
		if(maxNumOfBricks<1) {
			mBricks = 1;
		}
		else {
			mBricks = maxNumOfBricks;
		}
		if(startingDonation<10) {
			sDonation = 10;
		}
		else {
			sDonation = startingDonation;
		}
		if(p==null) {
			this.p = new Person("Unknown","Donation");
		}
		else {
			this.p = p;
		}
		cBricks = 0;
		bricks = new Brick [mBricks];
		hDonation = sDonation;
		hDonator = this.p;
		sDonations = sDonation;
		tDonation = tDonation + sDonations;
	}
	
	/**
	 * 
	 * @return how many bricks have been added to the wall
	 */
	public int getCurrentAmountOfBricks(){
		return cBricks;
	}
	
	/**
	 * 
	 * @return how many empty spots are left in the wall
	 */
	public int getAmountOfBricksLeftToAdd(){
		int a = mBricks - cBricks;
		return a;
	}
	
	/**
	 * 
	 * @return how much has currently been donated
	 */
	public int getCurrentDonationAmount(){
		return sDonations;
	}
	
	/**
	 * 
	 * @return The Person who donated the most in either the constructor(s) or the newDoner method
	 */
	public Person getPersonWhoDonatedTheMost(){
		return hDonator;
	}

	
	/**
	 * This method is called when a Person donates money to the wall
	 * 
	 * @param p The Person who donated the money
	 * @param amount The amount they donated
	 * 
	 * You will need to remember the Person who donated the most
	 * Ties remain with the first person who donated
	 * 
	 * GOTCHAS:
	 * Don't crash on invalid values for p, but still count the donation if it is good
	 * negative amounts shouldn't win, or change the total
	 */
	public void newDoner(Person p, int amount){
		if(p!=null) {
			this.p = p;
		}
		if(amount>hDonation) {
			if(p!=null) {
				hDonator = this.p;
			}
			hDonation = amount;
		}			
		if(amount<0) {
			amount = 0;
		}
		sDonations = sDonations + amount;
		tDonation = tDonation + amount;
	}

	
	
	/**
	 * This method adds a single brick at a time to the wall
	 * 
	 * Not shown is that you will need to remember every single brick added
	 */
	public void addABrick(Brick b){
		bricks[cBricks] = b;
		cBricks = cBricks + 1;
	}
	
	/**
	 * This method returns a brick that was added (but leaves it in the wall)
	 * 
	 * @param number The number of the brick.  Assume the first brick is number 0
	 * @return the Brick, or null if the number is bad
	 * 
	 * GOTCHAS:
	 * Don't crash on invalid numbers
	 */
	public Brick getABrickByNumber(int number){
		if(number<0 || number>mBricks) { 
			return null;
		} 
		else { 
			return bricks[number];
		}
	}
	
	/**
	 * Look through all the bricks and count the number that are broken
	 * @return the number of broken bricks
	 */
	public int howManyBricksAreBroken(){
		int a = 0;
		for(int i=0; i<mBricks; i++) {
			if(bricks[i].isBroken()==true) {
				a = a + 1;
			}
			else {
			}
		}
		return a;
	}
	
	/**
	 * Look through all the bricks and count the number that match param c
	 * @param c The Color of the brick
	 * @return the number of bricks of Color c
	 */
	public int howManyBricksAreThisColor(Color c){
		int a = 0;
		for(int i=0; i<mBricks; i++) {
			if(bricks[i].getColor().equals(c)) {
				a = a + 1;
			}
			else {
			}
		}
		return a;
	}
	
	/**
	 * This method should return the total amount of money made for every single brick wall
	 * 
	 * Doners donate in the newDoner method and also in the constructor
	 * 
	 * @return The total amount
	 */
	public static int howMuchMoneyWasMadeForAllBrickWalls(){
		return tDonation;
	}
	
	
}
