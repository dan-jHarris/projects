
public class Desk {

	private int numOfPapers;
	private int maxPapers;
	private boolean isLocked;
	private boolean isClosed;
	private Paper[] paperArray;
	private static int allTheDesks;


	/**
	 * The no argument constructor
	 * 
	 * A desk created with this constructor should:
	 * have no Papers in the drawer
	 * be locked
	 * have the drawer be closed
	 * have room for 10,000 Papers
	 */
	public Desk() {
		numOfPapers=0;
		maxPapers=10000;
		isLocked=true;
		isClosed=true;
		paperArray=new Paper[maxPapers];
		allTheDesks++;
	}

	/**
	 * This is the 3 argument constructor
	 * A desk created with this constructor should
	 * 
	 * have no Papers in the drawer
	 * be locked or unlocked base on the isLocked parameter
	 * have the maximum number of Papers specified in the maxNumberOfPapers variable
	 * be open or closed based on the isClosed variable
	 * 
	 * @param isLocked
	 * @param maxNumberOfPapers
	 * @param isClosed
	 * 
	 * GOTCHAS: Don't allow the maxNumberOfPapers to be less than 1000, but set it to 1000 if that is the case
	 */
	public Desk(boolean isLocked, int maxNumberOfPapers, boolean isClosed) {
		if(maxNumberOfPapers<1000) {
			maxPapers=1000;
		}
		else {
			maxPapers=maxNumberOfPapers;
		}
		this.isLocked=isLocked;
		this.isClosed=isClosed;
		numOfPapers=0;
		paperArray=new Paper[maxPapers];
		allTheDesks++;


	}

	/**
	 * 
	 * @return true if the desk is locked, or false if it is unlocked
	 */
	public boolean theDeskIsLocked() {
		if(isLocked==true) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 
	 * @return true if the desk is open, and false if it is closed
	 */
	public boolean theDrawerIsOpen() {
		if(isClosed==false) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 
	 * @return the number of papers that can still fit in the drawer
	 */
	public int howManyPapersCanStillFitInTheDrawer() {
		return maxPapers-numOfPapers;
	}

	/**
	 * This method opens the drawer
	 * 
	 * GOTCHAS:
	 * don't open the drawer if it is locked
	 * If the drawer is open, and they call this method again, leave it open 
	 */
	public void openDrawer() {
		if(isLocked!=true && isClosed!=false) {
			isClosed=false;
		}

	}

	/**
	 * This method closes the drawer
	 * 
	 * GOTCHAS:
	 * don't close the drawer if it is locked
	 * If the drawer is closed, and they call this method again, leave it closed 
	 */
	public void closeDrawer() {
		if(isLocked!=true && isClosed!=true) {
			isClosed=true;
		}

	}

	/**
	 * This method adds a paper to the drawer
	 * You will need to remember every paper added to the drawer
	 * 
	 * @param p The paper to be added
	 * 
	 * GOTCHAS:
	 * Don't allow more papers than can fit into the drawer.
	 * If someone tries to add too many papers, just don't add it, and don't crash
	 * 
	 * We could check for p == null, but let's assume that won't happen for this exam
	 * 
	 */
	public void addAPaperToDrawer(Paper p) {
		if(numOfPapers<maxPapers) {
			paperArray[numOfPapers]=p;
			numOfPapers++;
		}
	}

	/**
	 * This method looks through the desk for a paper
	 * @param p The Paper to look for
	 * @return true if that paper is in the desk, false if it isn't
	 */
	public boolean isThisPaperInTheDesk(Paper p) {
		for(int i=0; i<paperArray.length; i++) {
			if(p==paperArray[i]) {
				return true;
			}
		}

		return false;
	}

	/**
	 * This method looks at every paper for specific writing
	 * 
	 * @param s The writing to look for
	 * @return the number of papers with that writing
	 */
	public int howMayPapersHaveThisExactWriting(String s) {
		int counter=0;
		for(int i=0; i<numOfPapers; i++) {
			if( paperArray[i].getWriting() == s) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * This method looks at every paper for a specific height
	 * 
	 * @param height The height to look for
	 * @return how many papers are that high
	 */
	public int howManyPapersInTheDrawerAreThisHigh(int height) {
		int counter=0;
		for(int i=0; i<numOfPapers; i++) {
			if(paperArray[i].getHeight()==height) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * 
	 * @return the number of desks that have ever been created
	 */
	public static int howManyDesksHaveBeenCreated() {
		return allTheDesks;
	}
}
