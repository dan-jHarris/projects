package array;

public class intarray {
	public static void main(String[] args) {
		System.out.println("Hello World");
		int [] a= new int[10];
		
		int Bernard =2;
		
		for (int i=0; i<a.length; i++){
		a[i] = 2+ (2*Bernard);
			Bernard = Bernard + 2; 
			
			
			System.out.println(a[i]);
	}
		takeAnintAndAddOnetoIt(sum);
		System.out.println("the sum is still "+sum);
	}
	
	public stat void takeAnIntAndAddOneToIt(int theInt) {
		theArra[0]++
		
		
		;
		
	}
}
