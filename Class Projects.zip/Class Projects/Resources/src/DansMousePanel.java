import java.awt.*;
import java.awt.Dimension;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.event.*;


public class DansMousePanel extends JPanel  {
	private int diameter;
	private int x;
	private int y;
	private Color c;

	public DansMousePanel(int r, int x, int y) {
		this.x =x;
		this.y=y;
		c=Color.RED;

		this.setSize(300,400);
		this.setMinimumSize(new Dimension (300,400));
		
		DansMouseListener mouse=new DansMouseListener();
		this.addMouseMotionListener(mouse);
	}


	public Color getC() {
		return c;
	}


	public void setC(Color c) {
		this.c = c;
	}


	public int getRadius() {
		return diameter;
	}


	public void setRadius(int radius) {
		this.diameter = radius;
	}


	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public int getY() {
		return y;
	}


	public void setY(int y) {
		this.y = y;
	}
	@Override
	public void paintComponent(Graphics g) {

		g.setColor(Color.GRAY);
		//g.fillRect(0,0, Color.GRAY);

		g.setColor(c);
		g.fillOval(x,y,diameter,diameter);
	}

	private class DansMouseListener implements MouseListener, MouseMotionListener{

		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseDragged(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseMoved(MouseEvent arg0) {
			// TODO Auto-generated method stub
			x=arg0.getX();

			y=arg0.getY();
			repaint();

		}
	}

}
