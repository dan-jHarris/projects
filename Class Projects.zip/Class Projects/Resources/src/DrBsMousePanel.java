import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class DrBsMousePanel extends JPanel{
	
	private int diameter;
	private int x;
	private int y;
	private Color c;
	private boolean showTheCircle;
	
	
	public boolean isShowTheCircle() {
		return showTheCircle;
	}


	public void setShowTheCircle(boolean showTheCircle) {
		this.showTheCircle = showTheCircle;
		repaint();
	}


	public DrBsMousePanel(int r, int x, int y) {
		setRadius(r);
		this.x = x;
		this.y = y;
		c = Color.RED;
		
		showTheCircle = true;
		
		this.setSize(300, 400);
		this.setMinimumSize(new Dimension(300,400));
		
		DrBsMouseListener mouse = new DrBsMouseListener();
		this.addMouseMotionListener(mouse);
	}


	public Color getColor() {
		return c;
	}


	public void setColor(Color c) {
		this.c = c;
	}


	public int getRadius() {
		return diameter;
	}


	public void setRadius(int radius) {
		if(radius > 0) {
			this.diameter = radius;
		}
		else {
			this.diameter = 20;
		}
	}



	@Override
	public void paintComponent(Graphics g) {
		g.setColor(Color.GRAY);
		g.fillRect(0, 0, getWidth(), getHeight());

		if(showTheCircle == true) {
			g.setColor(c);
			g.fillOval(x-diameter/2, y-diameter/2, diameter, diameter);
		}
	}
	
	
	private class DrBsMouseListener implements MouseListener, MouseMotionListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			x = e.getX();
			y = e.getY();
			
			repaint();
			
		}
		
	}
	
}