import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * 
 * @author
 *
 */
@SuppressWarnings("serial")
public class MyMousePanel extends JPanel{

	public static final int theMagicNumber = 50;
	
	private int theX = 100;
	private int theY = 10;
	private Color c = Color.red;
	private JButton theButton;

	
	public void setX(int x){
		this.theX = x;
		
		repaint();
	}

	public int getTheX() {
		return theX-25;
	}

	public int getTheY() {
		return theY-25;
	}


	public void setY(int y){
		this.theY = y;

		repaint();
	}
	
	
	public MyMousePanel(JButton b){
		super();

		theButton = b;
	}
	
	public void changeTheColor(){
		c = new Color((float)Math.random(),(float)Math.random(),(float)Math.random());
		
		//theButton.setText("The color is now " + c.toString());
		
		repaint();
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		
		//Erase the old image
		g.setColor(Color.gray);
		g.fillRect(0, 0, 500, 500);
		
		g.setColor(c);
		g.fillOval(theX-25, theY-25, 50, 50);
		
		if(theY < this.getHeight()-25){
			theY++;
		}

		repaint();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
