import java.awt.Color;

/**
 * 
 * @author
 *
 */
public class Freeway {


	/**
	 * A new Freeway has 0 cars on it
	 * 
	 * @param name the name of the freeway
	 * @param numberOfLanes the number of lanes the freeway has
	 * @param freewayCapacity the total number of cars that can be on the freeway at any given time
	 *
	 * GOTCHA: there needs to be at least 1 lane, but no more than 6 (6 is ok).  If an
	 * improper value(less than 1 or more than 6) is given, set
	 * the number of lanes to 1
	 * 
	 * GOTCHA: freeway capacity should be at least 1.  On
	 * improper (negative or 0) values, set the number to 1 
	 */
	public Freeway(String name, int numberOfLanes, int freewayCapacity){

	}

	/**
	 * 
	 * @return
	 */
	public String getNameOfFreeway(){
		return null;
	}

	/**
	 * 
	 * @return the number of lanes the freeway has
	 */
	public int getNumberOfLanes(){
		return -1;
	}

	/**
	 * 
	 * @return the capacity of the freeway
	 */
	public int getFreewayCapacity(){
		return -1;
	}
	

	/**
	 * 
	 * @param c the Car to add to the freeway
	 * @return true if the car can be added to the freeway, or 
	 * false if there is no room for the car
	 * 
	 * GOTCHA: return false and don't crash on invalid data
	 * GOTCHA: return false if the car is already on the freeway
	 */
	public boolean addACar(Car c){

		return false;
	}

	/**
	 * 
	 * @return the number of cars currently on the freeway
	 */
	public int getNumberOfCarsOnFreeway(){
		return -1;
	}

	/**
	 * 
	 * @param c the color of the cars that I want to know about
	 * 
	 * @return How many cars are on the freeway that are Color c
	 * 
	 * GOTCHA: don't crash on invalid data and return 0
	 */
	public int getNumberOfCarsWithColor(Color c){
		return -1;
	}

	/**
	 * 
	 * @return  The number of cars on every freeway.  For example:
	 * If there were 3 freeways, and each had 10 cars then this method
	 * would return 30
	 */
	public static int getNumberOfCarsOnEveryFreeway(){
		return -1;
	}
	
}
