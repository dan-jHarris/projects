import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

java.awt.event.*;

/**
 * 
 * @author
 *
 */
public class GuiDesign extends JFrame{

	private JPasswordField pwd;
	private JLabel lbl;
	private JButton btn;

	@SuppressWarnings("unused")
	public static void dialogBoxes(){
		String s = JOptionPane.showInputDialog("Please enter a number");
		int x =Integer.parseInt(s);
		JOptionPane.showMessageDialog(null, "The number you entered is " + x);

	}


	public GuiDesign(){

		this.setSize(300,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new FlowLayout());
		this.setVisible(true);
		
		
		myActionListener listener = new myActionListener();
		

		lbl = new JLabel("Your mother was a hamster");
		add(lbl);
		//JTextField of size 10, with text already inside - uneditable
		JTextField fld=new JTextField("Type Something", 10);
		//fld.setEditable(false);
		add(fld);
		
		pwd = new JPasswordField(10);
		add(pwd);
		pwd.addActionListener(listener);
		btn = new JButton("Click Me");
		add(btn);
		btn.addActionListener(listener);
		JCheckBox box= new JCheckBox("Click this box if you have cmpleted the IDEA survey!");
		add(box);
		this.setVisible(true);
		//JCheckBox
		DansMousePanel p =new DansMousePanel(50,0,0);
		add(p);
	}
	private class myActionListener implements ActionListener, KeyListener{
		

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource() ==btn)
			System.out.println("They Clicked the Button. Time to get to work stealing their password.");
			String s = pwd.getText();
			lbl.setText(s);
			
		}

		@Override
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

	}

	public static void main(String[] args) {

		//dialogBoxes();

		GuiDesign g = new GuiDesign();

	}

}
