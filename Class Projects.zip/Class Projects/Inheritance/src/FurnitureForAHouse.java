import javafx.scene.paint.Color;

public class FurnitureForAHouse {
	

	public static void main (String []args) {
	Table brownTable=new Table("wood", Color.BROWN);
	Chair redChairs=new Chair("wood", Color.RED);
	Chair redChairs2=new Chair("wood", Color.RED);
	Chair redChairs3=new Chair("wood", Color.RED);
	Chair redChairs4=new Chair("wood", Color.RED);
	Chair couch=new Chair("cloth", Color.GREEN);
	TV bigTV=new TV(71, Color.BLACK);
	Piano tanPiano=Piano("wood", Color.TAN);
	Table glassTable=new Table("glass", Color.TRANSPARENT);
	Bed strawBed=new Bed("straw", Color.WHITE);
			
	
	brownTable.move("kitchen");
	redChairs.move("kitchen");
	redChairs2.move("Kitchen");
	redChairs3.move("Kitchen");
	redChairs4.move("Kitchen");
	bigTV.move("livingRoom");
	couch.move("livingRoom");
	glassTable.move("livingRoom");
	tanPiano.move("basement");
	strawBed.move("bedroom");
	}
}
