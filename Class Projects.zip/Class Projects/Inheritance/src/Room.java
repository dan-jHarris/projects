
public class Room {
	String name;
	int width;
	int height;
	int floorNum;


	public Room() {
		name="Spare oom";
		width=25;
		height=9;
		floorNum=1;
	}
	public Room(String nameOfRoom, int howWide, int howHigh, int whichFloor) {
		name=nameOfRoom;
		width=howWide;
		height=howHigh;
		floorNum=whichFloor;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getFloorNum() {
		return floorNum;
	}
	public void setFloorNum(int floorNum) {
		this.floorNum = floorNum;
	}




}
