import javafx.scene.paint.Color;

public class Piano {
String brand;
Color color;
Room place;
int width;
int length;
int height;

public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public Color getColor() {
	return color;
}
public void setColor(Color color) {
	this.color = color;
}
public Room getPlace() {
	return place;
}
public void setPlace(Room place) {
	this.place = place;
}
public int getWidth() {
	return width;
}
public void setWidth(int width) {
	this.width = width;
}
public int getLength() {
	return length;
}
public void setLength(int length) {
	this.length = length;
}
public int getHeight() {
	return height;
}
public void setHeight(int height) {
	this.height = height;
}
public Piano() {
brand="Yahmaha";
color=Color.BLACK;
place=new Room();
width=9;
length=13;
height=4;
}
public Piano(String brand, Color color, Room place, int width, int length, int height) {
	this.brand=brand;
	this.color=color;
	this.place=place;
	this.width=width;
	this.length=length;
	this.height=height;
}
}
