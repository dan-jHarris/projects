import javafx.scene.paint.Color;

public class Chair extends measurements {
	String brand;
	Color color;
	Room place;
	String type;


	public Chair() {
		brand="Lazy Boy";
		color=Color.BLACK;
		place=new Room();
		type="Recliner";

	}
	public Chair (String brandName, Color color, Room room, String whatKind) {
		brand=brandName;
		this.color=color;
		place=room;
		type=whatKind;
	}

	public String getBrand() {
		return brand;

	}
}
