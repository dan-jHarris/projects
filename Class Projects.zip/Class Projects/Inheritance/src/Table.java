import javafx.scene.paint.Color;

public class Table {
	String brand;
	Color color;
	Room place;
	int width;
	int height;
	int length;

	public Table() {
		brand= "Super tables";
		color= color.BROWN;
		place= new Room();
		width= 5;
		height= 4;
		length= 8;
	}
	public Table(String brand, Color color, Room room, int howWide, int howTall, int howLong) {
		this.brand=brand;
		this.color=color;
		place=room;
		width=howWide;
		height=howTall;
		length=howLong;
		
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public Room getPlace() {
		return place;
	}
	public void setPlace(Room place) {
		this.place = place;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
}