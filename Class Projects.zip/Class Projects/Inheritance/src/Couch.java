import javafx.scene.paint.Color;

public class Couch {
String brand;
Color color;
Room place;
int numOfCushions;
int length;


public Couch() {
	brand="Lazy Boy";
	color=Color.BLACK;
	place=new Room();
	numOfCushions=3;
	length=6;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public Color getColor() {
	return color;
}
public void setColor(Color color) {
	this.color = color;
}
public Room getPlace() {
	return place;
}
public void setPlace(Room place) {
	this.place = place;
}
public int getNumOfCushions() {
	return numOfCushions;
}
public void setNumOfCushions(int numOfCushions) {
	this.numOfCushions = numOfCushions;
}
public int getLength() {
	return length;
}
public void setLength(int length) {
	this.length = length;
}
public Couch(String brand, Color color, Room place, int numOfCushions, int length) {
	this.brand=brand;
	this.color=color;
	this.place=place;
	this.numOfCushions=numOfCushions;
	this.length=length;
}
}
