
public class measurements {
int cost;

}
