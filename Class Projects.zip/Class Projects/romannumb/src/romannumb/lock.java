package romannumb;

public class lock {
	int a =1;
	int b =2;
	int c =3;
	boolean isOpen=false;
	public static void main(String[] args) {
		

	}
	private boolean openTheLock(int a, int b, int c) {
		if(this.a==a && this.b==b && this.c==c) {
			isOpen=true;
			
		}
		return false;
	}



}
