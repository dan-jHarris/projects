package romannumb;

import java.util.ArrayList;

public class Person {
	public String getName() {
		return "Dan";
	}
	public static void main(String[] args) {
		Student s = new Student();
		System.out.println(s.getName());
	}

}
