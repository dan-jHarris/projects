package romannumb;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class doubletxt {

	public static void main (String [] args) {
		try{
			double [] a1;
			FileReader reader = new FileReader("doubletxtfile.txt");
			Scanner scanner = new Scanner(reader);
			int counter=0;
			while(scanner.hasNext()) {
				counter++;
			}
			a1=new double [counter];
			reader = new FileReader("doubletxtfile");
			scanner = new Scanner(reader);
			for(int i=0; i<counter; i++) {
				a1[i]=scanner.nextDouble();
			}
			//findMean(a1);
			//findMode(a1);
			//findMedian(a1);
		} catch(IOException e) {
			
		}
		
	}
}
