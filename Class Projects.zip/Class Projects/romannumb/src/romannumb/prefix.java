package romannumb;

public class prefix {

	public static void main(String[] args) {
		String s1="pro";
		String s2="professional";
		String s3="cow";
		if(prefix1(s1,s2)) {
			System.out.println("s1 is a prefix of s2");
		}
		else {
			System.out.println("s1 is not a prefix of s2");
		}
	}

	public static boolean prefix1 (String s1, String s2) {
		for(int i=0; i<s1.length(); i++) {
			if(s1.charAt(i)!=(s2.charAt(i))) {
				
				return false;
			}
		}
		return true;
	}
}