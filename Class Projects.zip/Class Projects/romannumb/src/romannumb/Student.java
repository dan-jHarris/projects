public class Student extends Person implements HasAName, SecondName{
	public  Anytype doSomething(Anytype a) {
		return null;
		
	}
}