package romannumb;

public class c1_19 {

	public static void main(String[] args) {
		integers(3.0, 7.0);
		}
	public static boolean integers (double a, double b) {
		if(a<b && b<1000 && (((Math.pow(a, 2.0)+(Math.pow(b, 2.0))+1.0)/(a*b))%1==0) && ((Math.pow(a, 2.0)+(Math.pow(b, 2.0))+1.0)/(a*b))>0) {
			return true;
		}
		else {
		return false;
		}
	}

}
