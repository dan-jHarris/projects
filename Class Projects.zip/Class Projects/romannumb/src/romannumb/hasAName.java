package romannumb;
import java.util.ArrayList;


	public static interface hasAName <AnyType? {
		public default String getName(Anytype t) {
			
			ArrayList
		return "no name";// TODO Auto-generated method stub

	}

}
