

package romannumb;
import java.util.*;
public class c1 {
	public static void main(String[] args) {
		maxOf3(2,3,4);
	}
public static int maxOf3 (int a,int b, int c) {
	int x=0;
	if(a>b && a>c) {
		 x=a;
	}
	if(b>a && b>c) {
		x=b;
	}
	if(c>a && c>b) {
		x=c;
	}
	else {
		System.out.println("At least two of the numbers are the same");
	}
	
	return x;
}

}

