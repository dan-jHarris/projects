import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Window.Type;

public class JFrameForTower extends JFrame {
	public JFrameForTower() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,400);
		
		getContentPane().setForeground(Color.WHITE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JButton btnExit = new JButton("Exit");
		GridBagConstraints gbc_btnExit = new GridBagConstraints();
		gbc_btnExit.insets = new Insets(0, 0, 5, 5);
		gbc_btnExit.gridx = 0;
		gbc_btnExit.gridy = 0;
		getContentPane().add(btnExit, gbc_btnExit);
		
		JLabel txt = new JLabel();
		
		
		MousePanel panel = new MousePanel(50, 100, 100, txt);
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 0);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 0;
		getContentPane().add(panel, gbc_panel);


		JButton btnBuyATower_1 = new JButton("Buy a Tower 2");
		GridBagConstraints gbc_btnBuyATower_1 = new GridBagConstraints();
		gbc_btnBuyATower_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnBuyATower_1.gridx = 0;
		gbc_btnBuyATower_1.gridy = 1;
		getContentPane().add(btnBuyATower_1, gbc_btnBuyATower_1);
		
		JButton btnStart = new JButton("Start");
		GridBagConstraints gbc_btnStart = new GridBagConstraints();
		gbc_btnStart.insets = new Insets(0, 0, 5, 0);
		gbc_btnStart.gridx = 1;
		gbc_btnStart.gridy = 1;
		getContentPane().add(btnStart, gbc_btnStart);
		
		JButton btnBuyATower = new JButton("Buy a Tower");
		GridBagConstraints gbc_btnBuyATower = new GridBagConstraints();
		gbc_btnBuyATower.insets = new Insets(0, 0, 0, 5);
		gbc_btnBuyATower.gridx = 0;
		gbc_btnBuyATower.gridy = 2;
		getContentPane().add(btnBuyATower, gbc_btnBuyATower);

		
		
		
		setVisible(true);
	}
	
	public static void main(String [] args) {
		JFrameForTower t = new JFrameForTower();
	}

}