import java.awt.image.BufferedImage;

public class Projectile extends MovingTowerDefenseObject {
	int damage;

	public Projectile(int x, int y, int width, int height, BufferedImage pic, double velocityX, double velocityY,
			int damage) {
		super(x, y, width, height, pic, velocityX, velocityY);
		this.damage = damage;
	}
	

}
