import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tower extends TowerDefenseObject {
	double radius;
	int time;
	int numOfShots;


	public Tower() {
		super();
		radius=20.0;
		time=1;
		numOfShots=1;
	}
	
	
	public Tower(int x, int y, int width, int height, BufferedImage pic, double radius, int time, int numOfShots) {
		super(x, y, width, height, pic);
		this.radius = radius;
		this.time = time;
		this.numOfShots = numOfShots;
	}

@Override
public void drawTheImage(Graphics g) {
	super.drawTheImage(g);
	time--;


}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getNumOfShots() {
		return numOfShots;
	}
	public void setNumOfShots(int numOfShots) {
		this.numOfShots = numOfShots;
	}
	
}
