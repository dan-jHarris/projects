import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class MovingTowerDefenseObject extends TowerDefenseObject{
	double velocityX;
	double velocityY;
	public MovingTowerDefenseObject(int x, int y, int width, int height, BufferedImage pic, double velocityX,
			double velocityY) {
		super(x, y, width, height, pic);
		this.velocityX = velocityX;
		this.velocityY = velocityY;
	}

	@Override
	public void drawTheImage(Graphics g) {
		super.drawTheImage(g);
		super.setPosistionX(super.getPosistionX()+(int)velocityX) ;
		super.setPosistionY(super.getPosistionY()+(int)velocityY) ;

	}

	




	public double getVelocityX() {
		return velocityX;
	}
	public void setVelocityX(double velocityX) {
		this.velocityX = velocityX;
	}
	public double getVelocityY() {
		return velocityY;
	}
	public void setVelocityY(double velocityY) {
		this.velocityY = velocityY;
	}



}


