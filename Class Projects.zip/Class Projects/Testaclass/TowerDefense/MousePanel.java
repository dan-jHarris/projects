import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.*;

public class MousePanel extends JPanel{

	private BufferedImage[][] imgs;
	private int rows;
	private int cols;
	private final int tileSize = 64;


	private int diameter;
	private int x;
	private int y;
	private Color c;
	private boolean showTheCircle;

	private JLabel lblLives;
	private int numLives;

	public boolean isShowTheCircle() {
		return showTheCircle;
	}


	public void setShowTheCircle(boolean showTheCircle) {
		this.showTheCircle = showTheCircle;
		repaint();
	}


	public MousePanel(int r, int x, int y, JLabel label) {
		setRadius(r);
		this.x = x;
		this.y = y;
		c = Color.RED;

		numLives=100;
		lblLives=label; 

		showTheCircle = true;


		DrBsMouseListener mouse = new DrBsMouseListener();
		this.addMouseMotionListener(mouse);



		//here at the wall
		//super("Maze");
		try {
			rows = 0;
			cols = 0;
			//Do Not Make Any Changes Above This Line


			//Here is where you need to ask the user to enter the name of the maze file, or just hard code it in
			//Scanner input=new Scanner(System.in);
			//System.out.println("name the maze");


			//String fileName=input.nextLine();
			String fileName="Maze1.txt";


			Scanner reader=new Scanner( new File(fileName));
			rows=reader.nextInt();
			cols=reader.nextInt();

			imgs = new BufferedImage[rows][cols];


			//Now the hard part.  Figure out what picture should be printed at each position
			//Using a Scanner you can read in ints and doubles, and Strings
			//Note: loops are very good for this type of exercise
			//The following method call adds picture A at position 0 0
			for(int j=0; j<rows; j++) {
				for(int i=0; i<cols; i++) {
					String s = reader.next();
					addPicture(j, i, s + ".png");
				}
			}









			//You can change the size of the Frame if you want
			this.setSize(600, 600);

			//Do Not Make Any Changes Below This Line
			this.setVisible(true);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	//fin






	public Color getColor() {
		return c;
	}


	public void setColor(Color c) {
		this.c = c;
	}


	public int getRadius() {
		return diameter;
	}


	public void setRadius(int radius) {
		if(radius > 0) {
			this.diameter = radius;
		}
		else {
			this.diameter = 20;
		}
	}



	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		//Draw the background
		for (int i = 0; i < rows; i++){
			for (int j = 0; j < cols; j++){
				g.drawImage(imgs[i][j], j*tileSize, i*tileSize, null);
			}
		}

		if(showTheCircle == true) {
			g.setColor(c);
			g.fillOval(x-diameter/2, y-diameter/2, diameter, diameter);
		}
	}


	private class DrBsMouseListener implements MouseListener, MouseMotionListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseMoved(MouseEvent e) {
			x = e.getX();
			y = e.getY();

			repaint();

		}

	}
	public void addPicture(int x, int y, String filename){
		if (x < 0 || x >= rows){
			System.err.println("There is no row " + x);
		}
		else if (y < 0 || y >= cols){
			System.err.println("There is no col " + y);
		}
		else{
			try {
				imgs[x][y] = ImageIO.read(new File(filename));
			} catch (IOException e) {
				System.err.println("Unable to read the file: " + filename);
			}
		}
	}


}