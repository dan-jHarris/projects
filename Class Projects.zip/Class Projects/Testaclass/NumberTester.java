/**
 * 
 * @author 
 *
 */
public class NumberTester {

	public static void main(String[] args) {
		testSimpleMethod();

		testFindIntegerMidPoint();
		testGetTheFirst5NumbersAfterTheDecimalPoint();
		testAddAllPositiveIntsTogetherUpToThisNumber();
		testFindTheTruthUsingAndOperator();

	}

	/*
	 * This method is just an example.  We will come up with some example in class Wednesday.  This test method is not graded
	 * If you miss class, feel free to email me for the code we typed up.
	 */
	public static void testSimpleMethod(){
		System.out.println("starting the tester");

		for(int i=Integer.MIN_VALUE; i < Integer.MAX_VALUE; i++) {
			int a = simpleMethod(i);
			if (i!=a) {
				System.out.println("I am passing a "+i+" and I got back the following int: "+a);


			}
		}
		System.out.println("stoping the tester");
		//int a = simpleMethod (0);
		//System.out.println("I am a passing a 0 and i got back the following int: " + a);

		//a=simpleMethod(1);
		//System.out.println(" i am passing a 1 and I got back the following int: "+a);
	}

	//This method should return exactly what it was given
	public static int simpleMethod(int i){
		return 0;
	}

	/*
	 * I would like you to write 3 test cases that would test and make sure the findIntegerMidPoint works correctly
	 */
	public static void testFindIntegerMidPoint(){
		int a = findIntegerMidPoint(-10,10);
		System.out.println("I am passing it something and i got back the following int: " + a);
		if (a==0) {
			System.out.println("that is correct");
		}
		else {System.out.println("That is incorrect");
		}
		int b = findIntegerMidPoint(-18,20);
		System.out.println("I am passing it something and i got back the following int: " + b);
		if(b==19) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}			
		int c = findIntegerMidPoint(5,7);
		System.out.println("I am passing it something and i got back the following int: " + c);
		if (c==0) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		return;
	}

	//This method should take 2 numbers (it does) and return the number in the middle of those 2 numbers
	public static int findIntegerMidPoint(int start, int end){
		//DO NOT WRITE ANY CODE FOR THIS METHOD YET


		return 0;
	}

	//I would like you to write 4 test cases that would test and make sure the addAllPositiveIntsTogetherUpToThisNumber works correctly
	//You cannot use any test cases (for points) with numbers less than 6
	public static void testAddAllPositiveIntsTogetherUpToThisNumber(){
		long a= addAllPositiveIntsTogetherUpToThisNumber(8);
		if (a==0) {
			System.out.println("Good job");
		}
		else {System.out.println("that is incorrect");
		}

		long b= addAllPositiveIntsTogetherUpToThisNumber(10);
		if (b==45) {
			System.out.println("That is correct");
		}
		else { System.out.println("That is incorrect");
		}
		long c= addAllPositiveIntsTogetherUpToThisNumber(11);
		if (c==55) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}

		long d= addAllPositiveIntsTogetherUpToThisNumber(12);
		if (d==66) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}

		return;
	}


	//This method should add up all the positive numbers up to the number given.
	//For example, if n was 2, this method would return 1 because that is all the positive numbers below 2
	//Another example, if n was 4, this method would return 6 because 1+2+3=6, and those are all the numbers less than 4
	public static long addAllPositiveIntsTogetherUpToThisNumber(int n){
		//DO NOT WRITE ANY CODE FOR THIS METHOD YET
		return 0;
	}


	//I would like you to write 5 test cases that would test and make sure the getTheFirst5NumbersAfterTheDecimalPoint method works correctly.
	//You cannot use any number that starts with 3 in your test cases
	public static void testGetTheFirst5NumbersAfterTheDecimalPoint(){
		int x=getTheFirst5NumbersAfterTheDecimalPoint(2.1159863);
		if(x==11598) {
			System.out.println("That is corect");
		}
		else {System.out.println("That is incorrect");
		}
		int y=getTheFirst5NumbersAfterTheDecimalPoint(6.88896452);
		if( y==88896) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		int z=getTheFirst5NumbersAfterTheDecimalPoint(8.664251);
		if(z==66425) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		int t=getTheFirst5NumbersAfterTheDecimalPoint(7.841395);
		if(t==84139) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		int i=getTheFirst5NumbersAfterTheDecimalPoint(1.222222);
		if (i==22222) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
	}
	//This method should return the first 5 numbers (as a positive int) after the decimal point.
	//For example, with 3.1415926535897932384 it would return 14159
	public static int getTheFirst5NumbersAfterTheDecimalPoint(double a){
		return 0;
	}


	//There are 8 possible values for the findTheTruthUsingAndOperator.  I want you to test all 8
	public static void testFindTheTruthUsingAndOperator(){
		boolean x=findTheTruthUsingAndOperator(false, false, false);
		if (x==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		//1

		boolean y=findTheTruthUsingAndOperator(false, false, true);
		if (y==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		//2	
		boolean z=findTheTruthUsingAndOperator(false, true, true);
		if (z==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");

		}
		//3	
		boolean a=findTheTruthUsingAndOperator(true, false, true);
		if (a==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}


		//4
		boolean b=findTheTruthUsingAndOperator(true, false, false);
		if (b==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}

		//5
		boolean c=findTheTruthUsingAndOperator(true, true, false);
		if (c==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}

		//6
		boolean d=findTheTruthUsingAndOperator(false, true, false);
		if (d==false) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		//7


		boolean t=findTheTruthUsingAndOperator(true, true, true);
		if (t==true) {
			System.out.println("That is correct");
		}
		else {System.out.println("That is incorrect");
		}
		//8

		return;
	}


	//Like Figure 4.13 in the book except with 3 values, this method should calculate the Conditional AND relationship  
	public static boolean findTheTruthUsingAndOperator(boolean a, boolean b, boolean c){
		return false;
	}

}
