
// List class

public class List {
	public Node firstNode;
	public Node lastNode;
	private String name;
	
	public List () {
		name = "default list";
		firstNode = lastNode = null;
	}
	
	public List (String s) {
		name = s;
		firstNode = lastNode = null;
	}
	
	public void insertAtFront (Object insertItem) {
		if (isEmpty()) {
			firstNode = lastNode = new Node(insertItem);
		}
		else{
			firstNode = new Node(insertItem, firstNode);
		}
	}
	public void insertAtBack (Object insertItem) {
		if(isEmpty()) {
			lastNode = firstNode = new Node(insertItem);
		}
		
		else { 
			lastNode.setNext(new Node (insertItem));
			lastNode = lastNode.getNext();
			
		}
	}
	public Object getFirstNode(){
		return firstNode.getObject();
	}
	
		public Object removeFromFront () {
			Object removeItem = null;
			if (isEmpty()) {
				removeItem = "This List is empty!";
				return removeItem;
			}
			removeItem = firstNode.getObject();
			if (firstNode.equals(lastNode)) {
					firstNode = lastNode = null;
			}
			else {
				firstNode = firstNode.getNext();
			}
			return removeItem;
		}

		public Object removeFromBack () {
		    Node temp = firstNode;
			Object removeItem = null;
			if (isEmpty()) {
				removeItem = "This List is empty!";
				return removeItem;
			}
			while (! temp.getNext().equals(lastNode)) {
				temp=temp.getNext();
			}
		removeItem=lastNode.getObject();
		temp.setNext(null);
		lastNode = temp;
		return removeItem;
		}
		
		public int length() {
			Node temp=firstNode;
			int counter=1;
			if( isEmpty()) {
				return 0;
			}
			else{
				while(temp!=lastNode) {
					temp=temp.getNext();
					counter++;
					
				}
				return counter;
			}
		}
		
		public boolean isEmpty () {
			return (firstNode == null);
		}
		
		public String print() {
			int counter=0;
			String result = "";
			String newline = "\n";
			if (isEmpty()) {
				result += "Empty " + name + newline;
				return result;
			}
			result += name + " contains: " + newline;
			Node current = firstNode;
			while (current != null) {
				result += current.getObject() + newline;
				current = current.getNext();
			
			
			}
				return result;
			}
		
}
