import java.util.*;
public class HashTable {
	List [] table;
	int key;
	int value;
	int prime;
	
	public HashTable(int prime) {
		this.prime=prime;
		table = new List[prime];
		for( int i = 0; i <prime; i++) {
			
			table[i]=new List();
		}
	}
		
	public void insert(int insertion) {
		int hash= insertion%prime;
		table[hash].insertAtFront(insertion);
	}
	
	public void delete (int del) {
		int hash=del%prime;			
		table[hash].removeFromFront();
	}
		
	public void print () {
		for(int i=0; i <table.length; i++) {
			System.out.println("At index " +i +" contains " +table[i].print());
		}
	}
}