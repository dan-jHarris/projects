

public class HashTester {
	
		public static void main (String args[]){
			HashTable table= new HashTable(31);
			
			for(int i=0; i< 100; i++) {
				int x=(int)(Math.random()*1000000);
				
				
				table.insert(x);
				
				}
		
			System.out.println("*********");
			table.print();
			System.out.println("*********");
				

				}

	

}
