import  algoritharium.*;

import java.awt.Color;

//Important Notes
//Double click the algoritharium.jar file to load the gui
//Create a new picture, or load a picture
//Select Code -> Load and your DrBsPaintableCanvas.class file

//Eclipse should auto-compile every time you save your file

//Select Code -> Reload if you add methods, but otherwise, you probably shouldn't have to

public class PaintableCanvas2 {

	/*
	 * When I coded this up, I had to think about there only being 1 single line.  That meant
	 * I needed to code it up different than before, where I had to repeat things for the entire image.
	 * 
	 * Also, I noticed that I could think about it like, draw to the right, interspersed with drawing down every 5
	 * 
	 * You can check for every 5 with (variable name)%5=0
	 * 
	 */
	public void steps ( ) {
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();
		int a=0;
		for(int y=0;y<numPixelsHigh && a<numPixelsWide; y++) {
			img.setPixelColor(a, y, Color.BLACK);
			if (y%5 == 0 && y!=0) {



				for (int x=a; x<(a+5) && x <numPixelsWide; x++) {
					img.setPixelColor(x, y, Color.BLACK);
				}
				a+=5;

			}
		}
	}

	public void squares(){
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();

		for(int x=0; x<numPixelsWide; x++) {
			for (int y=0; y<numPixelsHigh; y++){
				img.setPixelColor(x, y, Color.BLACK);


			}
		}
		for( int a=numPixelsWide/5; a<(4*numPixelsWide)/5; a++) {
			for (int b=numPixelsHigh/5; b<(4*numPixelsHigh/5); b++) {
				img.setPixelColor(a, b, Color.DARK_GRAY);
			}

		}

		for (int w=(2*numPixelsWide)/5; w< (3*numPixelsWide)/5; w++) {
			for(int e=(2*numPixelsHigh)/5; e<(3*numPixelsHigh)/5; e++) {
				img.setPixelColor(w, e, Color.LIGHT_GRAY);
			}
		}

	}


	//Use these 3 colors
	//img.setPixelColor(1, 1, Color.BLACK);
	//img.setPixelColor(1, 1, Color.DARK_GRAY);
	//img.setPixelColor(1, 1, Color.LIGHT_GRAY);


	public void boundaries(){

		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();

		for(int x=numPixelsWide/5; x<(4*numPixelsWide/5); x++){
			img.setPixelColor(x, numPixelsHigh/5, Color.DARK_GRAY);
			img.setPixelColor(x, (4*numPixelsHigh)/5, Color.DARK_GRAY);
			for(int a=(2*numPixelsWide)/5; a<(3*numPixelsWide)/5; a++ ) {
				img.setPixelColor(a,(2*numPixelsHigh)/5, Color.DARK_GRAY);
				img.setPixelColor(a, (3*numPixelsHigh)/5, Color.DARK_GRAY);
			}


		}
		for (int y=numPixelsHigh/5; y<(4*numPixelsHigh)/5; y++) {
			img.setPixelColor(numPixelsWide/5, y, Color.DARK_GRAY);
			img.setPixelColor((4*numPixelsWide)/5, y, Color.DARK_GRAY);
			for(int b= 2*numPixelsHigh/5; b<3*numPixelsHigh/5; b++) {
				img.setPixelColor(2*numPixelsWide/5, b, Color.DARK_GRAY);
				img.setPixelColor(3*numPixelsWide/5, b, Color.DARK_GRAY);
			}
		}

	}




	public void random_Movement(){
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();


		//img.setPixelColor(numPixelsWide/2, numPixelsHigh/2, Color.DARK_GRAY);
		int x= numPixelsWide/2;
		int y= numPixelsHigh/2;
		while (x< numPixelsWide && x>0 && y<numPixelsHigh && y>0) {
			//for(int i=0; i<10; i++) {
			img.setPixelColor(x, y, Color.DARK_GRAY);
			int a=(int)(Math.random()*4);
			//System.out.println(a);
			if(a==0) {

				x+=1;

			}
			else if(a==1) {
				y+=1;

			}
			else if(a==2) {
				x-=1;

			}
			else if(a==3) {
				y-=1;


			}
		

		}




	}

}
