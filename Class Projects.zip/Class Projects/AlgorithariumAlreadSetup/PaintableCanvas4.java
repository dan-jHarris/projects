import  algoritharium.*;

import java.awt.Color;

public class PaintableCanvas4 {


	public void drawA0(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA1(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA2(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA3(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA4(){
		Image img = ImageViewer.getImage();
		//Your code here
	}


	public void drawA5(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA6(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA7(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA8(){
		Image img = ImageViewer.getImage();
		//Your code here
	}
	public void drawA9(){
		Image img = ImageViewer.getImage();
		//Your code here
	}



}
