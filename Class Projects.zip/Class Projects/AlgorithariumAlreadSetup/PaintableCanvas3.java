import  algoritharium.*;

import java.awt.Color;

public class PaintableCanvas3 {


	public void howManyStars(){
		Image img = ImageViewer.getImage();
		int stars = 0;
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();

		for(int x=0; x<numPixelsWide; x++) {
			for (int y=0; y<numPixelsHigh; y++){
				Color c = img.getPixelColor(x, y);
				int r=c.getRed();
				int g=c.getGreen();
				int b=c.getBlue();
				if (r==255 && g==255 && b==255) {
					stars+=1;
				}
			}
		}

		//Color c = img.getPixelColor(0, 0);
		//int r=c.getRed();
		//int g=c.getGreen();
		//int b=c.getBlue();
		//Leave this at the end
		//A bit of a hack to get your answer printed at the top of the screen
		ImageViewer.getFrames()[0].setTitle("There were " + stars + " stars");
	}

	public void howManyPureRedPixels(){
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();
		int num = 0;

		for(int x=0; x<numPixelsWide; x++) {
			for (int y=0; y<numPixelsHigh; y++){
				Color c = img.getPixelColor(x, y);
				int r=c.getRed();
				int g=c.getGreen();
				int b=c.getBlue();
				if (r==255 && g==0 && b==0) {
					num+=1;
				}
			}	
			ImageViewer.getFrames()[0].setTitle("There were " + num + " red pixels");
		}
	}

	public void howManyPureGreenPixels(){
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();
		int num = 0;

		for(int x=0; x<numPixelsWide; x++) {
			for (int y=0; y<numPixelsHigh; y++){
				Color c = img.getPixelColor(x, y);
				int r=c.getRed();
				int g=c.getGreen();
				int b=c.getBlue();
				if (g==255 && r==0 && b==0) {
					num+=1;
				}
			}	

			ImageViewer.getFrames()[0].setTitle("There were " + num + " green pixels");
		}
	}

	public void howManyPureBluePixels(){
		Image img = ImageViewer.getImage();
		int numPixelsWide = img.getWidth();
		int numPixelsHigh = img.getHeight();
		int num = 0;

		for(int x=0; x<numPixelsWide; x++) {
			for (int y=0; y<numPixelsHigh; y++){
				Color c = img.getPixelColor(x, y);
				int r=c.getRed();
				int g=c.getGreen();
				int b=c.getBlue();
				if (b==255 && r==0 && g==0) {
					num+=1;
				}
			}	




			ImageViewer.getFrames()[0].setTitle("There were " + num + " blue pixels");
		}
	}
}
