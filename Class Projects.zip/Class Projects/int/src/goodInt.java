import java.util.Scanner;
public class goodInt {

	public static void main(String[] args) {


Scanner input =new Scanner(System.in);
		System.out.println("Please enter in a number");
		int x=input.nextInt();
		if(x<0) {
			System.out.println("A proper integer should be positive");
		}
			if(0<x && x<10) {
				System.out.println("That number is too small");
			}
			if (11<x && x<50) {
				System.out.println("That is a great number!");
			}
			if (50<x) {
				System.out.println("That number is too big");
			}
			
		}
	}



	


