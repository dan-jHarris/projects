
package AntFarm;
/**
 * 
 * @author
 *
 */
public class AntFarm {
	private int maxAnts;
	private int numOfTunnels;
	private int numOfAnts;
	private Ant [] ants;
	private static int allTheTunnels;

	/**
	 * This constructor creates a new Ant Farm
	 * 
	 * An ant farm created with this constructor should have
	 * 
	 * @param maxAnts The maximum number of Ants the farm can ever have
	 * and 1 tunnel
	 * 
	 * GOTCHAS: Do not allow less than 1 maxAnt, or crash on invalid numbers.
	 */
	public AntFarm(int maxAnts){
		if( maxAnts>0){
			this.maxAnts=maxAnts;
		}
		else {
			this.maxAnts=1;
		}
		numOfTunnels=1;
		ants =new Ant [this.maxAnts];
		numOfAnts=0;
		allTheTunnels+=numOfTunnels;
	}


	/**
	 * This method should
	 * @return the current number of tunnels in the farm
	 */
	public int getNumberOfTunnels(){
		return numOfTunnels;
	}

	/**
	 * @return the total number of tunnels in every ant farm ever created
	 */
	public static int getTheTotalNumberOfTunnelsInEveryAntFarm(){
		return allTheTunnels;
	}

	/**
	 * This method should add a tunnel to the farm
	 */
	public void addATunnelToTheFarm(){
		numOfTunnels++;
		allTheTunnels++;
	}

	/**
	 *This method should add an ant to the Farm 
	 * @param a the Ant to add
	 * @return true if there is room for the Ant, or false if there are too many ants
	 */
	public boolean addAnAnt(Ant a){
		if(numOfAnts<maxAnts) {
			ants[numOfAnts]= a;
			numOfAnts++;
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * This method 
	 * @param a The Ant that we are looking for
	 * @return true if the ant is in the Farm, false if it is not
	 */
	public boolean isThisAntInTheFarm(Ant a){
		for(int i=0; i<ants.length; i++) {
			if(a == ants[i]) {
				return true;
			}

		}



		return false;
	}


	/**
	 * @return the number of Ants that are Worker Ants
	 */
	public int howManyAntsAreWorkerAnts(){
		int numOfworkers=0;
		for(int i=0; i<ants.length; i++) {
			if(ants[i].isAWorker()==true) {
				numOfworkers++;
			}
		}
		return numOfworkers;
	}

	/**
	 * @return the number of Ants that are Builder Ants
	 */
	public int howManyAntsAreBuilderAnts(){
		int numOfbuilders=0;
		for(int i=0; i<ants.length; i++ ) {
			if(ants[i].isABuilder()==true) {
				numOfbuilders++;
			}
		}
		return numOfbuilders;
	}

	/**
	 * @return true if there are 2 of more Queen ants, false otherwise
	 */
	public boolean canTheAntsStartANewFarm(){
		int numOfQueens=0;
		for(int i=0; i<ants.length; i++) {
			if(ants[i].isAQueen()==true) {
				numOfQueens++;
			}
		}
		if(numOfQueens<2) {
			return false;
		}
		else {
			return true;
		}
	}

	/**
	 * @return true if there are no Queen ants in the farm, false otherwise
	 */
	public boolean willTheAntFarmDie(){

		int numOfQueens=0;
		for(int i=0; i<ants.length; i++) {
			if(ants[i].isAQueen()==true) {
				numOfQueens++;
			}
		}
		if(numOfQueens<1) {
			return true;
		}
		else {
			return false;
		}
	}
}
