/**
 * 
 * @author barkern
 *
 */
public class Ant {

	private final int occupation;
	
	public final static int WORKER = 0;
	public final static int BUILDER = 1;
	public final static int QUEEN = 2;
	
	public Ant(int o){
		occupation = o;
	}
	
	public boolean isAWorker(){
		return occupation==WORKER;
	}
	
	public boolean isABuilder(){
		return occupation == BUILDER;
	}
	
	public boolean isAQueen(){
		return occupation == QUEEN;
	}
	
	
}
