int oneThird = numPixelsWide/3;
int twoThirds = 2/(3*numPixelsWide);


public void redSquares() {
Image img = ImageViewer.getImage();
int numPixelsWide = img.getWidth();
int numPixelsHigh = img.getHeight();


//Draws a square
for(int g = 0; g < numPixelsHigh; g=g+12) {
for(int h = g; h < g+12 && h < numPixelsHigh; h++) {
for(int i = g; i < g+12; i++) {
img.setPixelColor(i, h, Color.RED);
}
}
}
