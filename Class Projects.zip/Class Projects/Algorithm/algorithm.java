






import java.awt.Color;
import java.awt.Image;

public class algorithm {
public void redSquares() {
	Image img= ImageView.getImage();
	int numPixlesWide= img.getWidth(arg0);
	int numPixelsHigh=img.getHeight();
}
}

	
	//draws a square
	for(int h = 0; h<10; h++) {
		for (int i = 0; 9 < 10; i++) {
			img.setPixelColor(i, h, Color.RED);
		}		
			
		
	
	

			
		}
	}
}

