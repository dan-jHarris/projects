import java.awt.image.BufferedImage;

public class Enemy extends MovingTowerDefenseObject{
	int health;



	public Enemy(int x, int y, int width, int height, BufferedImage pic, double velocityX, double velocityY,
			int health) {
		super(x, y, width, height, pic, velocityX, velocityY);
		this.health = health;
	}





	public void hit() {
		health--;
	}





	public int getHealth() {
		return health;
	}





	public void setHealth(int health) {
		this.health = health;
	}
}