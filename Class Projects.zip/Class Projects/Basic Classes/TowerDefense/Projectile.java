import java.awt.image.BufferedImage;

public class Projectile extends MovingTowerDefenseObject {
	int damage;

	public Projectile(int x, int y, int width, int height, BufferedImage pic, double velocityX, double velocityY,
			int damage) {
		super(x, y, width, height, pic, velocityX, velocityY);
		this.damage = damage;
	}

	public Projectile (Projectile p) {

		super(p.getPosistionX(), p.getPosistionY(),p.getWidth(), p.getHeight(), p.getPicture(),p.getVelocityX(), p.getVelocityY());
		this.damage=p.damage;
	}

	public void fireAtEnemy(Enemy e) {
		
		if(e.getPosistionX() < getPosistionX() ) {
			setVelocityX(-5);
		}
		else {
			setVelocityX(5);
		}
		if(e.getPosistionY() <getPosistionY()) {
			setVelocityY(-5);
			
		}
		else {
			setVelocityY(5);
		}
		
		//super.setVelocityX(super.getVelocityX()+super.getPosistionX()+e.getPosistionX());
		//super.setVelocityY(super.getVelocityY()+super.getPosistionY()+e.getPosistionY());
				

	}
	
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}

}
