import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tower extends TowerDefenseObject {
	double radius;
	int time;
	int delayOfShot;
	Projectile projectile;


	public Tower() {
		super();
		radius=20.0;
		time=1;
		delayOfShot=1;
	}


	public Tower(int x, int y, int width, int height, BufferedImage pic, double radius, int time, int numOfShots, Projectile projectile) {
		super(x, y, width, height, pic);
		this.radius = radius;
		this.time = time;
		this.delayOfShot = numOfShots;
		this.projectile = projectile;
	}
	public Projectile fireAtEnemy(Enemy e) {
		if(time>0) {
			return null;
		}
		else {
			time=delayOfShot;

		}
		Projectile a=new Projectile(projectile);

		a.fireAtEnemy(e);


		return a;


	}
	public boolean canFire() {
		if(time<=0) {
			return true;
		}
		else {
			return false;
		}
		
		
		
	}
	@Override
	public void drawTheImage(Graphics g) {
		super.drawTheImage(g);
		time--;


	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getNumOfShots() {
		return delayOfShot;
	}
	public void setNumOfShots(int numOfShots) {
		this.delayOfShot = numOfShots;

	}


	public Projectile getProjectile() {
		return projectile;
	}


	public void setProjectile(Projectile projectile) {
		this.projectile = projectile;
	}

}
