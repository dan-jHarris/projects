import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Window.Type;

public class TowerGui extends JFrame {
	public TowerGui() {
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setForeground(Color.WHITE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JButton btnExit = new JButton("Exit");
		GridBagConstraints gbc_btnExit = new GridBagConstraints();
		gbc_btnExit.insets = new Insets(0, 0, 5, 5);
		gbc_btnExit.gridx = 0;
		gbc_btnExit.gridy = 0;
		getContentPane().add(btnExit, gbc_btnExit);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 0);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 0;
		getContentPane().add(panel, gbc_panel);
		
		JButton btnBuyATower_1 = new JButton("Buy a Tower 2");
		GridBagConstraints gbc_btnBuyATower_1 = new GridBagConstraints();
		gbc_btnBuyATower_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnBuyATower_1.gridx = 0;
		gbc_btnBuyATower_1.gridy = 1;
		getContentPane().add(btnBuyATower_1, gbc_btnBuyATower_1);
		
		JButton btnBuyATower = new JButton("Buy a Tower");
		GridBagConstraints gbc_btnBuyATower = new GridBagConstraints();
		gbc_btnBuyATower.insets = new Insets(0, 0, 0, 5);
		gbc_btnBuyATower.gridx = 0;
		gbc_btnBuyATower.gridy = 2;
		getContentPane().add(btnBuyATower, gbc_btnBuyATower);
	}
	
	

}