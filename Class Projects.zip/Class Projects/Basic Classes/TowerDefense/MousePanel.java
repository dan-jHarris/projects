import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.*;

public class MousePanel extends JPanel{

	private BufferedImage[][] imgs;
	private int rows;
	private int cols;
	private int money;
	private final int tileSize = 64;

	private BufferedImage projectileImage;
	private BufferedImage towerImage;
	private Enemy[] enemyArray;
	private Tower[] towerArray;
	private Projectile[] projectileArray;
	private int numOfProj;
	private int numTowers=0;


	private int diameter;
	private int x;
	private int y;
	private Color c;
	private boolean showTheCircle;
	private JLabel currency;
	private JLabel lblLives;
	private int numLives;


	public boolean isShowTheCircle() {
		return showTheCircle;
	}


	public void setShowTheCircle(boolean showTheCircle) {
		this.showTheCircle = showTheCircle;
		repaint();
	}


	public MousePanel(int r, int x, int y, JLabel label, JLabel currency) {
		setRadius(r);
		this.x = x;
		this.y = y;
		c = Color.RED;

		numLives=25;
		lblLives=label; 
		lblLives.setText("Lives"+numLives);
		showTheCircle = false;

		money=100;
		this.currency=currency;
		currency.setText("Money "+ money);

		DrBsMouseListener mouse = new DrBsMouseListener();
		this.addMouseListener(mouse);
		this.addMouseMotionListener(mouse);

		//Makes the tower array
		towerArray=new Tower[10];
		enemyArray=new Enemy[5];

		//makes the projectile array
		projectileArray=new Projectile[50000000];

		//here at the wall
		//super("Maze");
		try {
			towerImage = ImageIO.read(new File("harry.jpg"));
			projectileImage=ImageIO.read(new File("stag.png"));
			rows = 0;
			cols = 0;
			//Do Not Make Any Changes Above This Line

			//calls on the maze file
			String fileName="Maze1.txt";

			Scanner reader=new Scanner( new File(fileName));
			rows=reader.nextInt();
			cols=reader.nextInt();

			imgs = new BufferedImage[rows][cols];

			//this is the file reader
			for(int j=0; j<rows; j++) {
				for(int i=0; i<cols; i++) {
					String s = reader.next();
					addPicture(j, i, s + ".png");
				}
			}
			//You can change the size of the Frame if you want
			this.setSize(600, 600);
			GridBagLayout gridBagLayout = new GridBagLayout();
			gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
			gridBagLayout.rowHeights = new int[]{0, 0};
			gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
			gridBagLayout.rowWeights = new double[]{0.0, Double.MIN_VALUE};
			setLayout(gridBagLayout);

			//Do Not Make Any Changes Below This Line
			this.setVisible(true);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//fin
	public Color getColor() {
		return c;
	}
	public void setColor(Color c) {
		this.c = c;
	}

	public int getRadius() {
		return diameter;
	}

	public void setRadius(int radius) {
		if(radius > 0) {
			this.diameter = radius;
		}
		else {
			this.diameter = 20;
		}
	}

	//PAINTS THE STUFF----------------------------------------------------------------------------------------------------------------------
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		//Draw the background
		for (int i = 0; i < rows; i++){
			for (int j = 0; j < cols; j++){
				g.drawImage(imgs[i][j], j*tileSize, i*tileSize, null);
			}
		}

		//Draw the thing that follows the mouse
		if(showTheCircle == true) {
			g.drawImage(towerImage, x, y, 64, 64, null);	
		}

		//Draw all the enemies
		if(enemyArray != null) {
			for(int i = 0; i < enemyArray.length; i++) {
				if(enemyArray[i] != null) {

					if(enemyArray[i].getHealth() > 0) {
						enemyArray[i].drawTheImage(g);

					}
					if(enemyArray[i].getPosistionX()>400) {
						enemyArray[i]=null;
						numLives--;
						lblLives.setText("Lives"+numLives);
					}
				}
			}		
		}

		//Draw all the Towers
		for(int i=0; i<numTowers; i++) {
			towerArray[i].drawTheImage(g);
			for(int j=0; j<enemyArray.length;j++) {
				if(towerArray[i].canFire()==true && enemyArray[j]!=null) {
					projectileArray[numOfProj]=towerArray[i].fireAtEnemy(enemyArray[j]);
					if(projectileArray[numOfProj] != null) {
						numOfProj++;
					}
				}
			}
		}
		//Draw all the projectiles
		for(int i=0; i<numOfProj; i++) {
			projectileArray[i].drawTheImage(g);
		}

		try {
			repaint();
			Thread.sleep(30);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


		//HIT DETECTION
		for (int i=0;i<enemyArray.length; i++) {
			for( int j=0; j<projectileArray.length; j++) {
				if(enemyArray[i]!=null) {
					if(projectileArray[j]!=null) {
						if(enemyArray[i].getPosistionX() < projectileArray[j].getPosistionX() && enemyArray[i].getPosistionY() <projectileArray[j].getPosistionY()
								&& enemyArray[i].getPosistionX()+32>projectileArray[j].getPosistionX()
								&&enemyArray[i].getPosistionY()+32 >projectileArray[j].getPosistionY()) {
							enemyArray[i].setHealth(enemyArray[i].getHealth()-projectileArray[j].getDamage());
						}
						if(enemyArray[i].getHealth()<=0) {
							enemyArray[i]=null;
						}


					}
				}
			}
		}

	}
	//STARTS THE GAME-SPAWNS ENEMIES -----------------------------------------------------------------------------------------------------
	public void startGame() {
		try {


			BufferedImage enemyImage1 = ImageIO.read(new File("dementor.jpg"));
			BufferedImage enemyImage2 = ImageIO.read(new File("deathEater.jpg"));

			for(int i = 0; i < enemyArray.length; i++) {
				if(i%2 == 0) {
					enemyArray[i] = new Enemy(i*100*-1,75,40,40,enemyImage1,5.5,0,20);
				}
				else {
					enemyArray[i] = new Enemy(i*100*-1,75,40,40,enemyImage2,5.5,0,100);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//PLACE A TOWER METHOD-------------------------------------------------------------------------------------------------
	public void  placeTowers(int towerNum) {
		try {

			if(towerNum == 1) {
				towerImage =ImageIO.read(new File("harry.jpg"));
			}
			else{
				towerImage =ImageIO.read(new File("dumbledore.png"));
			}
			showTheCircle = true;
			money-=15;
			currency.setText("Money "+money);



		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



	//--------------------------------------------------------------------------------------------------------------------------------
	//MOUSE LISTENER------------------------------------------------------------------------------------------------------------------
	private class DrBsMouseListener implements MouseListener, MouseMotionListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			showTheCircle=false;
			Projectile spell= new Projectile(e.getX(),e.getY(),10,10,projectileImage,20.0,20.0,1);
			towerArray[numTowers]=new Tower(e.getX(),e.getY(),64,64,towerImage,40.0,1,1, spell);
			numTowers++;
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseMoved(MouseEvent e) {
			x = e.getX();
			y = e.getY();

			repaint();

		}
	}
	public void addPicture(int x, int y, String filename){
		if (x < 0 || x >= rows){
			System.err.println("There is no row " + x);
		}
		else if (y < 0 || y >= cols){
			System.err.println("There is no col " + y);
		}
		else{
			try {
				imgs[x][y] = ImageIO.read(new File(filename));
			} catch (IOException e) {
				System.err.println("Unable to read the file: " + filename);
			}
		}
	}
}