import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Window.Type;

public class JFrameForTower extends JFrame {
	public JFrameForTower() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,400);

		getContentPane().setForeground(Color.WHITE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);

		JButton btnExit = new JButton("Exit");
		GridBagConstraints gbc_btnExit = new GridBagConstraints();
		gbc_btnExit.insets = new Insets(0, 0, 5, 5);
		gbc_btnExit.gridx = 0;
		gbc_btnExit.gridy = 0;
		getContentPane().add(btnExit, gbc_btnExit);
		
		JLabel currency = new JLabel("Money");
		GridBagConstraints gbc_currency = new GridBagConstraints();
		gbc_currency.insets = new Insets(0, 0, 5, 0);
		gbc_currency.gridx = 1;
		gbc_currency.gridy = 1;
		getContentPane().add(currency, gbc_currency);

	

		JLabel lblLives = new JLabel("Lives");
		GridBagConstraints gbc_lblLives = new GridBagConstraints();
		gbc_lblLives.gridx = 1;
		gbc_lblLives.gridy = 3;
		getContentPane().add(lblLives, gbc_lblLives);

		MousePanel panel = new MousePanel(50, 100, 100, lblLives, currency );
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 0);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 0;
		getContentPane().add(panel, gbc_panel);

		//button for a tower
		JButton btnBuyATower_1 = new JButton("Buy a Tower 2");
		btnBuyATower_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			panel.placeTowers(2);
			}
		});
		GridBagConstraints gbc_btnBuyATower_1 = new GridBagConstraints();
		gbc_btnBuyATower_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnBuyATower_1.gridx = 0;
		gbc_btnBuyATower_1.gridy = 2;
		getContentPane().add(btnBuyATower_1, gbc_btnBuyATower_1);
	
		
		//starts the game
		JButton btnStart = new JButton("Start");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.startGame();
			}
		});


		//the start button
		GridBagConstraints gbc_btnStart = new GridBagConstraints();
		gbc_btnStart.insets = new Insets(0, 0, 5, 0);
		gbc_btnStart.gridx = 1;
		gbc_btnStart.gridy = 2;
		getContentPane().add(btnStart, gbc_btnStart);
		
		//buy another tower
		JButton btnBuyATower = new JButton("Buy a Tower");
		btnBuyATower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel.placeTowers(1);
			}
		});
		GridBagConstraints gbc_btnBuyATower = new GridBagConstraints();
		gbc_btnBuyATower.insets = new Insets(0, 0, 0, 5);
		gbc_btnBuyATower.gridx = 0;
		gbc_btnBuyATower.gridy = 3;
		getContentPane().add(btnBuyATower, gbc_btnBuyATower);






		setVisible(true);
	}

	public static void main(String [] args) {
		JFrameForTower t = new JFrameForTower();
	}

}