import java.util.Scanner; 


public class puttingItAllTogether {
	public static int method5(){
		int x=(int)((Math.random()*3));
		return x-1;
	}




	public static int method7(){

		int x=(int)(Math.random()*5);
		int [] y= {2,4,6,8,10};


		return y[x]; 
	}



	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		int a=method5();
		System.out.println("How many times would you like to run method 5?");
		int b=input.nextInt();

		int c=method7();
		System.out.println("How many times would you like to run method 7?");
		int d=input.nextInt();

		int num1=0;
		int num2=0;
		int num3=0;

		int x[]=new int [b];
		int y[]= new int [d];
		for(int i=0; i<b; i++) {
			x[i]= method5();
			//System.out.print(x[i]+",");
			if(x[i] ==-1) {
				num1++;
			}		
			if(x[i]==0) {
				num2++;
			}
			if(x[i]==1) {
				num3++;
			}
		}
		System.out.println();
		System.out.println("num of -1's: "+num1);
		System.out.println("num of 0's: "+num2);
		System.out.println("num of 1's: "+num3);

		int [] f=new int[11];



		System.out.println();
		for(int i=0; i<d; i++) {
			y[i]= method7();
			f[y[i]]++;

			//	System.out.print(y[i]+",");

		}
		System.out.println("num of 2's "+f[2]);
		System.out.println("num of 4's "+f[4]);
		System.out.println("num of 6's "+f[6]);
		System.out.println("num of 8's "+f[8]);
		System.out.println("num of 10's "+f[10]);

	}
}

