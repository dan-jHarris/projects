
public class GraduationRobe{
private String name;
private int amountofDollars;
private int amountofPennies;
private String [] nameofPins;
private int spotInArray;
	/**
	 * 
	 * This is the 3 argument constructor
	 * 
	 * @param ownersName
	 * @param numberOfDollars
	 * @param numOfPennies
	 * 
	 * Not shown is a way to add the name of pins to the robe
	 * Assume no more than 300 will ever be added due to the weight of the pins
	 * 
	 * GOTCHAS:
	 * Make sure the owners name is not null - If it is set it to "Hagrid"
	 * Make sure that the numOfDollars is positive, if not set it to 0
	 * Make sure that the numOfPennies is positive, if not set it to 0
	 */
	public GraduationRobe(String ownersName, int numberOfDollars, int numOfPennies){
		//The owners name or string defined
		this.name = ownersName;
		if(ownersName==null) {
			this.name="Hagrid";
		}
		
		//The amount of dollars defined
		this.amountofDollars = numberOfDollars;
		if(numberOfDollars < 0) {
			this.amountofDollars = 0;
		}
		
		//The amount of pennies defined
		this.amountofPennies = numOfPennies;
		if(numOfPennies < 0) {
			this.amountofPennies = 0;
		}
		
		//The int [] array defined
		this.nameofPins = new String [300];
		spotInArray = 0;
		
	}

	/**
	 * This is the copy constructor.  Make an exact copy of g
	 * 
	 * Ideally you would do a deep copy, but that is currently not graded
	 * 
	 * @param g
	 */
	public GraduationRobe(GraduationRobe g){
		//Creates the deep copy
		//Also, checks for null and if null sets default values
		if(g == null) {
			this.name="Hagrid";
			this.amountofDollars = 0;
			this.amountofPennies = 0;
			this.nameofPins = new String [300];
			this.spotInArray = 0;
		}
		else {
			this.nameofPins = new String [g.nameofPins.length];
			for (int i = 0; i < g.nameofPins.length; i++) {
				this.nameofPins[i] = g.nameofPins[i];
			}
			this.name = g.name;
			this.amountofDollars = g.amountofDollars;
			this.amountofPennies = g.amountofPennies;
			this.spotInArray = g.spotInArray;
		}
		
	}

	/**
	 * 
	 * @return the name of the owner of the robe
	 */
	public String getTheOwnersName(){
		return name;
	}

	/**
	 * 
	 * @return the price of the robe.
	 * 
	 * If it cost 20 dollars and 45 pennies, it would return 20.45
	 * 
	 * (Hint: divide the pennies by 100)
	 * 
	 */
	public double getCostOfRobe(){
		//Calculates number of pennies
		//Calculates number of dollars
		//Adds the two sums together
		//Return sum
		//Needs double pennies for we can get a decimal amountofPennies / 100.
		//Need a double sum in order to return a double answer
		double pennies = amountofPennies / 100.;
		int dollars = amountofDollars;
		double sum = pennies + dollars;
		
		return sum;
	}

	/**
	 * This method adds a pin to the robe.
	 * 
	 * Assume the first pin has the number 0, and the next pin has the number 1, etc.
	 * 
	 * @param nameOfThePin
	 * 
	 * GOTCHAS:
	 * Don't do anything on null pin names
	 */
	public void addAPinToTheRobe(String nameOfThePin){
		//Create a if that disregards null values
		//this.weights[this.spotInArray] allows us to add things to the array...
		//this.spotInArray += 1; says if the value in numOfThePin is positive...
		//increase the value by one
		if (nameOfThePin!=null) {
			this.nameofPins[this.spotInArray] = nameOfThePin;
			this.spotInArray += 1;
		}
	}

	/**
	 * @return how many pins are currently on the robe
	 */
	public int getNumberOfPinsOnRobe(){
		return spotInArray;
	}

	/**
	 * 
	 * @param numberOfPin
	 * @return the name associated with the pin number.
	 * 
	 * Assume the first pin has the number 0, the second has the number 1, etc.
	 * 
	 * GOTCHAS:
	 * don't crash and return null if the number is invalid
	 */
	public String getNameOfPin(int numberOfPin){
		if (numberOfPin<0 || numberOfPin>spotInArray-1) {
			return null;
		}
		else {
			return nameofPins[numberOfPin];
		}
	}
	
	/**
	 * @param c
	 * @return the number of pins that start with the character c
	 */
	public int getNumberOfPinsThatStartWith(char c){
		//Characters can be compared with ==, and stringName.charAt(0) give you the first character in the string
		int a = 0;
		for(int i=0; i<spotInArray; i++) {
			if(nameofPins[i].charAt(0)==c) {
				a = a + 1;
			}
		}
		return a;
	}
	
}

