
public class wolverine {
	private int StabWounds;
	private double BloodLoss;
	private int BodyCount;

	public wolverine () {
		StabWounds=4;
		BloodLoss =8.5;
		BodyCount=46;
	}
	public wolverine(int a, double b, int c) {
		StabWounds=a;
		BloodLoss=b;
		BodyCount=c;
	}
	public int getStabWounds() {
		return StabWounds;
	}
	public void setStabWounds(int stabWounds) {
		StabWounds = stabWounds;
	}
	public double getBloodLoss() {
		return BloodLoss;
	}
	public void setBloodLoss(double bloodLoss) {
		BloodLoss = bloodLoss;
	}
	public int getBodyCount() {
		return BodyCount;
	}
	public void setBodyCount(int bodyCount) {
		BodyCount = bodyCount;
	}
}





