
public class GraduationRobeGrader{

	public static void main (String [] args){

		int points = 100;
		int deduction = points/8;

		System.out.println("Testing 3 argument Constructor and getters");
		try{

			for(int i = 0; i < 100; i++){

				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				if(!ownerName.equals(p.getTheOwnersName()) ||  notClose(price,p.getCostOfRobe())){
					points -= deduction;
					System.out.println("\tError");
					break;
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}

		System.out.println("Testing 3 argument Constructor and getters on bad values");
		try{

			for(int i = 0; i < 100; i++){

				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);

				GraduationRobe p1 = new GraduationRobe(null,(int) price, cents);
				GraduationRobe p2 = new GraduationRobe(ownerName,(int) price*-1, cents);
				GraduationRobe p3 = new GraduationRobe(ownerName,(int) price, cents*-1);

				if(!"Hagrid".equals(p1.getTheOwnersName()) ||  notClose(price,p1.getCostOfRobe()) ||
						!ownerName.equals(p2.getTheOwnersName()) ||  notClose(cents/100.0,p2.getCostOfRobe()) ||
						!ownerName.equals(p3.getTheOwnersName()) ||  notClose(price-cents,p3.getCostOfRobe())
						){
					points -= deduction;
					System.out.println("\tError");
					break;
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}


		System.out.println("Testing addAPinToTheRobe and getNumberOfPinsOnRobe");
		try{

			for(int i = 0; i < 100; i++){

				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				for(int j = 0; j < 100; j++){
					String pinName = "Pin " + generateName();
					p.addAPinToTheRobe(pinName);
					if(p.getNumberOfPinsOnRobe() != j+1){
						points -= deduction;
						System.out.println("\tError");
						i = 100;
						break;
					}
				}

			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}

		System.out.println("Testing addAPinToTheRobe and getNumberOfPinsOnRobe for BAD values");
		try{

			for(int i = 0; i < 100; i++){

				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				int realNumber = 0;
				for(int j = 0; j < 100; j++){
					String pinName = "Pin " + generateName();
					if(Math.random() < 0.5){
						p.addAPinToTheRobe(pinName);
						realNumber++;
					}
					else{
						p.addAPinToTheRobe(null);
					}

					if(p.getNumberOfPinsOnRobe() != realNumber){
						points -= deduction;
						System.out.println("\tError");
						i = 100;
						break;
					}
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}



		System.out.println("Testing addAPinToTheRobe and getNameOfPin");
		try{

			for(int i = 0; i < 100; i++){
				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				String [] names = new String[100];
				for(int j = 0; j < 100; j++){
					String pinName = "Pin " + generateName();
					p.addAPinToTheRobe(pinName);
					names[j] = pinName;
				}
				for(int j = 0; j < 100; j++){
					if(!names[j].equals(p.getNameOfPin(j))){
						points -= deduction;
						System.out.println("\tError");
						i = 100;
						break;
					}
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}


		System.out.println("Testing addAPinToTheRobe and getNameOfPin for BAD values");
		try{

			for(int i = 0; i < 100; i++){
				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				String [] names = new String[100];
				for(int j = 0; j < 100; j++){
					String pinName = "Pin " + generateName();
					p.addAPinToTheRobe(pinName);
					names[j] = pinName;
				}
				for(int j = 0; j < 100; j++){
					if(Math.random() < 0.5){
						if(null != (p.getNameOfPin((int)(Math.random()*-100.0-1)))){
							points -= deduction;
							System.out.println("\tError");
							i = 100;
							break;
						}
					}
					else{
						if(null != (p.getNameOfPin((int)(Math.random()*100000.0+100)))){
							points -= deduction;
							System.out.println("\tError");
							i = 100;
							break;
						}
					}
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}

		System.out.println("Testing addAPinToTheRobe and getNumberOfPinsThatStartWith");
		try{

			for(int i = 0; i < 100; i++){
				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);
				
				char [] chars = {'a','b','c','d','e','f','g','h','i','j','k','l','m','o','p','q','r','s','t','u','v','w','x','y','z'};
				char c = chars[(int)(Math.random()*13)];
				int numOfStartingThings = 0;

				for(int j = 0; j < 100; j++){
					if(Math.random() < 0.5){
						String pinName = c + " Pin " + generateName();
						p.addAPinToTheRobe(pinName);
						numOfStartingThings++;
					}
					else{
						String pinName = (c+Math.random()*12+1) + " Pin " + generateName();
						p.addAPinToTheRobe(pinName);
					}
				}
				if(p.getNumberOfPinsThatStartWith(c) != numOfStartingThings){
					points -= deduction;
					System.out.println("\tError");
					i = 100;
					break;
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}

		System.out.println("Testing copy Constructor and getters, including getNumberOfPinsOnRobe, and getNameOfPin");
		try{

			for(int i = 0; i < 100; i++){

				String ownerName = "Owner " + generateName();
				double price = Math.round((Math.random()*1000+1000)*100)/100;
				int cents = (int)((price - ((int)price))*100);
				GraduationRobe p = new GraduationRobe(ownerName,(int) price, cents);

				int numOfPinsOnRobe = 0;
				int theRand = (int)(Math.random()*50+10);
				for(int j = 0; j < theRand; j++){
					p.addAPinToTheRobe("Pin " + generateName());
					numOfPinsOnRobe++;
				}
				//Stick a random name in the middle
				String randomName = "Pin " + generateName();
				p.addAPinToTheRobe(randomName);
				int nameSpot = numOfPinsOnRobe;
				numOfPinsOnRobe++;
				for(int j = 0; j < theRand; j++){
					p.addAPinToTheRobe("Pin " + generateName());
					numOfPinsOnRobe++;
				}
				
				GraduationRobe p2 = new GraduationRobe(p);

				if(!ownerName.equals(p2.getTheOwnersName()) ||  notClose(price,p2.getCostOfRobe()) || p2.getNumberOfPinsOnRobe() != numOfPinsOnRobe || !randomName.equals(p2.getNameOfPin(nameSpot))){
					points -= deduction;
					System.out.println("\tError");
					break;
				}
			}

		}
		catch(Exception e){
			e.printStackTrace();
			points -= deduction;
			System.out.println("\tError");
		}


		if(points < 5){
			points = 0;
		}
		System.out.println("Score for GraduationRobeGrader: " + points);

	}

	public static boolean notClose(double a, double b){
		double ep = 0.0000001;
		if(a + ep > b && b + ep > a){
			return false;
		}
		return true;
	}

	public static String generateName(){
		String t = "";
		String [] args = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		for(int j = 0; j < 200; j++){
			int rand = (int)(Math.random()*args.length);
			t = t + args[rand];
		}
		return t;
	}


}
