
public class tree {

	private int leaves;
	private String name;
	private double height;


	public tree() {
		leaves=623;
		name= null;
		height =60.4;
	}

	public tree(int x, String y, double z) {
		leaves=x;
		name=y;
		height=z;

	}

	public int getLeaves() {
		return leaves;
	}

	public void setLeaves(int leaves) {
		this.leaves = leaves;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
}
