
public class Elevator100{
	private String name;
	private int mfloor;
	private int mweight;
	private int cfloor;
	private int cweight;
	private String [] list;
	/**
	 * The 2 parameter constructor
	 * 
	 * An elevator constructed with this constructor should have or be:
	 * @param numFloorsHigh - How high the elevator can go
	 * @param maxWeight - The maximum weight capacity of the elevator
	 * A current weight of 2 (due to the carpet, or something)
	 * The ability to hold 17 people - You will remember their names as Strings
	 * No people on the elevator currently
	 * Be on the first (1) floor
	 * 
	 * GOTCHAS - Elevators must be at least 2 floors high, but no more than 70
	 * Elevators floor numbers start at 1
	 * On bad numFloorsHigh values, set the number to 10
	 * 
	 * The maxWeight must be at least 1,000, with a max limit of 50,000
	 * on bad values, set the maximum weight to 4000
	 */
	public Elevator100(int f, int w){
		if(f<2 || f>70) {
			mfloor = 10;
		}
		else {
			mfloor = f;
		}
		cfloor = 1;
		if(w<1000 || w>50000) {
			mweight = 4000;
		}
		else {
			mweight = w;
		}
		cweight = 2;
		list = new String [17];
	}
	
	/**
	 * This is the copy constructor.
	 * Make sure you create an exact copy of e
	 * @param e The elevator to copy
	 * 
	 * GOTCHAS: Don't forget to do a deep copy
	 */
	public Elevator100(Elevator100 e){
		list = new String [17];
		for (int i=0; i<17; i++) {
			list[i]=e.list[i];
		}
		this.cweight = e.cweight;
		this.cfloor = e.cfloor;
		this.mweight = e.mweight;
		this.mfloor = e.mfloor;
	}

	/**
	 * @return how many floors the elevator spans
	 */
	public int getNumFloorsHigh(){
		return mfloor;
	}

	/**
	 * @return the maximum weight the elevator can hold
	 */
	public int getMaxWeight(){
		return mweight;
	}

	/**
	 * @return how much weight the elevator currently holds
	 */
	public int getCurrentWeightInElevator(){
		return cweight;
	}

	/**
	 * @return which floor the elevator currently is on
	 */
	public int getCurrentFloor(){
		return cfloor;
	}

	/**
	 * @return How many people are on the elevator currently
	 */
	public int getCurrentNumberOfPeopleOnTheElevator(){
		int a = 0;
		for(int i=0; i<17; i++) {
			if(list[i]!=null) {
				a = a + 1;
			}
		}
		return a;
	}
	
	/**
	 * This methods 'moves' the elevator to a different floor
	 * 
	 * @param floorNumber The new floor number
	 * 
	 * GOTCHAS - Don't allow invalid floor numbers (less than 1), but keep the elevator on the same floor in those cases
	 */
	public void goToFloor(int fn){
		if(fn>=1) {
			cfloor = fn;
		}
		else {
		}
	}

	/**
	 * This is the method that allows people on the elevator
	 * 
	 * @param nameOfPerson
	 * @param weightOfPerson
	 * 
	 * You don't need to remember everyone's weight individually, but you do need to remember each person's name
	 * Assume the first person to enter the elevator has a number of 0
	 * After this method call, there should be 1 more person on the elevator than before
	 * 
	 * GOTCHAS - There are some, but due to time limits, I won't make you code them in.
	 * Just assume these will be good numbers
	 */
	public void personEnteredElevator(String nameOfPerson, int weightOfPerson){
		cweight = cweight + weightOfPerson;
		for(int i=0; i<17; i++) {
			if(list[i]==null) {
				list[i] = nameOfPerson;
				return; 
			}
			else {
			}
		}
	}
	
	/**
	 * 
	 * @param number The number of the person we want the name for
	 * @return The person's name
	 * 
	 * GOTCHAS - Don't crash on invalid numbers, but return "INVALID" in those cases
	 * Remember, if only 1 person is on the elevator, then 8 is "INVALID"
	 */
	public String getPersonByNumber(int number){
		if(number>=0 && number<=16 && list[number]!=null) {
			return list[number];
		}
		else {
			return "INVALID";
		}
	}
	
}

