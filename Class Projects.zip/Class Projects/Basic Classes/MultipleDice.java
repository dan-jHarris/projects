import java.util.Scanner;
public class MultipleDice {
	public static double rollDie() {
		double x=Math.random();
		return x;
	}

	public static void main(String [] args) {

		Scanner input=new Scanner(System.in);

		System.out.println("How many sides will the first die have?");
		int die1=input.nextInt();

		System.out.println("How many sides will the second die have?");
		int die2=input.nextInt();

		System.out.println("How many times do you want to roll the die?");
		int numOfRolls=input.nextInt();
		int record [][]=new int [die1+1][die2+1];
		for(int i=0; i<numOfRolls; i++) {
			int roll1=(int)((rollDie()*die1)+1);
			int roll2=(int)((rollDie()*die2)+1);
			record [roll1][roll2]++;

		}
		for (int a=1; a< die1+1; a++) {
			for(int b=1; b<die2+1; b++) {
				
				System.out.print(record[a][b]+" ");
			}System.out.println();
		}

	}
}
