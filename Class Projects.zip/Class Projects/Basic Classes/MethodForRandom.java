/**
 * 
 * @author
 *
 */
public class MethodForRandom {

	/**
	 * 
	 * @return an integer in the range 1 <= n <= 2
	 */
	public static int method1(){
		double x=(Math.random()*2);
	if(x>1) {
		return 2;
	
	}
	else {
		return 1;
	}
	}

	/**
	 * 
	 * @return an integer in the range 1 <= n <= 100
	 */
	public static int method2(){
		int x=(int)((Math.random()*100)+1);
		return x;
	}

	/**
	 * 
	 * @return an integer in the range 0 <= n <= 9
	 */
	public static int method3(){
		int x=(int)((Math.random()*10));
		return x;
	}

	/**
	 * 
	 * @return an integer in the range 1000 <= n <= 1112
	 */
	public static int method4(){
		int x=(int)((Math.random()*113)+1000);
		return x;
	}

	/**
	 * 
	 * @return an integer in the range -1 <= n <= 1
	 */
	public static int method5(){
		int x=(int)((Math.random()*3));
		return x-1;
	}

	/**
	 * 
	 * @return an integer in the range -3 <= n <= 11
	 */
	public static int method6(){
int x=(int)((Math.random()*15));
		return x-3;
	}

	/**
	 * 
	 * @return an integer in the set 2,4,6,8,10
	 */
	public static int method7(){
		//int x=(int)((((Math.random()*5)+1)*2));
		int x=(int)(Math.random()*5);
		int [] y= {2,4,6,8,10};
		
		
		return y[x]; 
	}

	/**
	 * 
	 * @return an integer in the set 3,5,7,9,11
	 */
	public static int method8(){
		//int x=(int)((((Math.random()*5)+1)*2)+1);
		int x=(int)(Math.random()*5);
		int [] y= {3,5,7,9,11};
		return y[x];
	}

	/**
	 * 
	 * @return an integer in the set 6,10,14,18,22
	 */
	public static int method9(){
		int x=(int)(Math.random()*5);
		int [] y= {6,10,14,18,22};
		return y[x];
	}


	/**
	 * 
	 * @return an integer in the set -22,-18,-14,-10,-6 
	 */
	public static int method10(){
		int x=(int)(Math.random()*5);
		int [] y= {-22,-18,-14,-10,-6 };
		return y[x];
	}

	public static void main (String [] args) {
		int a = method5();
		System.out.println(a);
		for(a=0; a<args.length; a++) {

		}
	}
}