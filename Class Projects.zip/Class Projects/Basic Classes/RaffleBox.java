
public class RaffleBox {
	int maxTickets;
	String name;
	int ticketsInBox;
	boolean activeRaffle;
	int [] ticketNumbers;

	/**
	 * This class tries to model a Raffle Box
	 * A Raffle box is a box that contains a large number of tickets
	 * 
	 * @param maxTickets The maximum number of tickets that can fit inside the box
	 * @param nameOfEvent The name of the event being used for this raffle
	 * 
	 * Not Shown:
	 * There are currently no tickets in the box
	 * The raffle is currently active, meaning tickets can be added to the box
	 * 
	 * GOTCHAS:
	 * Don't let there ever be less than 1 maxTicket, but set it to 1 if that is the case
	 * Don't let the nameOfEvent be null, but set it to "Holiday Trip" if that is the case
	 */
	public RaffleBox(int maxTickets, String nameOfEvent) {
		if(maxTickets<1) {
			this.maxTickets=1;
		}
		else {
			this.maxTickets=maxTickets;
		}
		if(nameOfEvent==null) {
			name="Holiday Trip";
		}
		else {
			name=nameOfEvent;
		}
		ticketsInBox=0;
		activeRaffle=true;
		ticketNumbers=new int [this.maxTickets];
	}

	/**
	 * The copy constructor
	 * @param box the RaffleBox to be copied
	 * 
	 * GOTCHAS:
	 * Don't allow null jar's, but set the values to what is described in the 2 argument
	 * constructor
	 * 
	 * Don't forget to do a deep copy
	 */
	public RaffleBox(RaffleBox box) {
		if(box==null) {
			this.name="Holiday Trip";
			this.maxTickets=1;
			this.ticketsInBox=0;
			this.activeRaffle=true;
			this.ticketNumbers=new int [maxTickets];
		}
		else {
			this.ticketNumbers= new int[box.ticketNumbers.length];
			for(int i=0; i<box.ticketNumbers.length; i++) {
				this.ticketNumbers[i]=box.ticketNumbers[i];

			}

			name=box.name;
			maxTickets=box.maxTickets;
			ticketsInBox=box.ticketsInBox;
			activeRaffle=box.activeRaffle;


		}
	}



	/**
	 * 
	 * @return how many tickets can fit into the box
	 */
	public int getMaximumNumberOfTicketsBoxCanContain() {
		return this.maxTickets;
	}

	/**
	 * 
	 * @return how many tickets currently are in the box
	 */
	public int getCurrentNumberOfTicketsInBox() {
		return ticketsInBox;
	}

	/**
	 * 
	 * @return the name of the event
	 */
	public String getNameOfEvent() {
		return name;
	}

	/**
	 * 
	 * @return true if the raffle is currently active, false if it is not
	 */

	public boolean isRaffelStillActive() {
		return activeRaffle;
	}

	/**
	 * Calling this method stops the raffle and no more tickets can be added to the box
	 */
	public void endRaffel() {
		activeRaffle=false;
	}

	/**
	 * Calling this method allows tickets to be added to the box
	 */
	public void reopenRaffel() {
		activeRaffle=true;
	}

	/**
	 * This method adds tickets into the box
	 * 
	 * @param ticketNumber The number of the ticket
	 * Assume all integer values are valid ticket numbers
	 * 
	 * GOTCHAS:
	 * Don't allow a ticket number to be added that already exists in the box
	 * Don't allow more tickets to be added then can fit in the box
	 */
	public void addTicketToBox(int ticketNumber) {

		if(ticketsInBox<maxTickets && activeRaffle==true) {
			for(int i=0; i<maxTickets; i++) {
				if(ticketNumbers[i] == ticketNumber) {
					return; 
				}
				if(ticketNumbers[i] == 0){
					ticketNumbers[i] =ticketNumber;
					ticketsInBox++;

					return;
				}

			}
		}
	}
	/**
	 * 
	 * @param ticketNumber
	 * @return true if this ticket number is in the box, false if it is not
	 */
	public boolean isThisTicketInTheBox(int ticketNumber) {
		for(int i=0; i<this.ticketNumbers.length; i++) {
			if(ticketNumbers[i] == ticketNumber) {
				return true;
			}
		}
		return false;
	}

}
