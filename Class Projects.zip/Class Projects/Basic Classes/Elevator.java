
public class Elevator{
	int numFloorsHigh;
	int maxWeight;
	int currentWeight;
	int currentFloor;
	String[] People;
	int numPeople;
	/**
	 * The 2 parameter constructor
	 * 
	 * An elevator constructed with this constructor should have or be:
	 * @param numFloorsHigh - How high the elevator can go
	 * @param maxWeight - The maximum weight capacity of the elevator
	 * A current weight of 2 (due to the carpet, or something)
	 * The ability to hold 17 people - You will remember their names as Strings
	 * No people on the elevator currently
	 * Be on the first (1) floor
	 * 
	 * GOTCHAS - Elevators must be at least 2 floors high, but no more than 70
	 * Elevators floor numbers start at 1
	 * On bad numFloorsHigh values, set the number to 10
	 * 
	 * The maxWeight must be at least 1,000, with a max limit of 50,000
	 * on bad values, set the maximum weight to 4000
	 */
	public Elevator(int numFloorsHigh, int maxWeight){
		if(numFloorsHigh<2 || numFloorsHigh>70 ) {
			this.numFloorsHigh=10;
		}
		else {
			this.numFloorsHigh=numFloorsHigh;
		}
		if(maxWeight>50000 || maxWeight<1000) {
			this.maxWeight=4000;
		}
		else {
			this.maxWeight = maxWeight;
		}
		People=new String[17];
		currentFloor=1;
		currentWeight=2;
		numPeople=0;
	}

	/**
	 * This is the copy constructor.
	 * Make sure you create an exact copy of e
	 * @param e The elevator to copy
	 * 
	 * GOTCHAS: Don't forget to do a deep copy
	 */
	public Elevator(Elevator e){
		this.numFloorsHigh=e.numFloorsHigh;

		this.currentFloor=e.currentFloor;
		this.maxWeight=e.maxWeight;
		this.currentWeight=e.currentWeight;
		this.People=new String[e.People.length];
		this.numPeople=e.numPeople;
		for(int i=0; i<17; i++) {
			this.People[i]=e.People[i];
		}

	}

	/**
	 * @return how many floors the elevator spans
	 */
	public int getNumFloorsHigh(){
		return this.numFloorsHigh;
	}

	/**
	 * @return the maximum weight the elevator can hold
	 */
	public int getMaxWeight(){
		return this.maxWeight;
	}

	/**
	 * @return how much weight the elevator currently holds
	 */
	public int getCurrentWeightInElevator(){
		return currentWeight;
	}

	/**
	 * @return which floor the elevator currently is on
	 */
	public int getCurrentFloor(){
		return this.currentFloor;
	}

	/**
	 * @return How many people are on the elevator currently
	 */
	public int getCurrentNumberOfPeopleOnTheElevator(){
		return numPeople;


	}

	/**
	 * This methods 'moves' the elevator to a different floor
	 * 
	 * @param floorNumber The new floor number
	 * 
	 * GOTCHAS - Don't allow invalid floor numbers (less than 1), but keep the elevator on the same floor in those cases
	 */
	public void goToFloor(int floorNumber){
		if(floorNumber<1) {
			this.currentFloor=currentFloor;
		}
		else {
			this.currentFloor=floorNumber;		

		}

	}

	/**
	 * This is the method that allows people on the elevator
	 * 
	 * @param nameOfPerson
	 * @param weightOfPerson
	 * 
	 * You don't need to remember everyone's weight individually, but you do need to remember each person's name
	 * Assume the first person to enter the elevator has a number of 0
	 * After this method call, there should be 1 more person on the elevator than before
	 * 
	 * GOTCHAS - There are some, but due to time limits, I won't make you code them in.
	 * Just assume these will be good numbers
	 */
	public void personEnteredElevator(String nameOfPerson, int weightOfPerson){
		People[numPeople]=nameOfPerson;
		this.currentWeight=currentWeight+weightOfPerson;
		numPeople++;
	}

	/**
	 * 
	 * @param number The number of the person we want the name for
	 * @return The person's name
	 * 
	 * GOTCHAS - Don't crash on invalid numbers, but return "INVALID" in those cases
	 * Remember, if only 1 person is on the elevator, then 8 is "INVALID"
	 */
	public String getPersonByNumber(int number){
		if(number>=0 && number<=16 && People[number]!=null) {
			return People[number];
		}
		else {
			return "INVALID";
		}
	}

}

